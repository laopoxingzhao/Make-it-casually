package com.example.bookborrowing.fragment;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import com.example.bookborrowing.R;
import com.example.bookborrowing.db.AboutDB;
import com.example.bookborrowing.db.DataBaseHelper;

import java.util.List;
import java.util.Map;


public class HomeFragment extends Fragment {


    public HomeFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ListView bookListView,bookListView1;

        bookListView = (ListView) view.findViewById(R.id.bookListView);
        bookListView1 = (ListView) view.findViewById(R.id.bookListView1);
        DataBaseHelper dataBaseHelper = new DataBaseHelper(getContext());
        SQLiteDatabase database = dataBaseHelper.getReadableDatabase();
        List<Map<String, Object>> bookList = AboutDB.getAllBookList(database);
        List<Map<String, Object>> topThreeBooks = bookList.subList(0, Math.min(bookList.size(), 2));
        List<Map<String, Object>> topThreeBooks1 = bookList.subList(1, Math.min(bookList.size(), 3));
        bookListView.setAdapter(new SimpleAdapter(
                getActivity().getApplicationContext(),topThreeBooks , R.layout.book_list_item_1,
                new String[] { "_id", "name", "author", "publish" },
                new int[] { R.id.list_book_id, R.id.list_book_name,
                        R.id.list_book_author, R.id.list_book_publish,
                       }));
        bookListView1.setAdapter(new SimpleAdapter(
                getActivity().getApplicationContext(),topThreeBooks1 , R.layout.book_list_item_1,
                new String[] { "_id", "name", "author", "publish" },
                new int[] { R.id.list_book_id, R.id.list_book_name,
                        R.id.list_book_author, R.id.list_book_publish}));
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }
}