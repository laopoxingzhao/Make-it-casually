package com.example.bookborrowing.listener;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.example.bookborrowing.db.AboutDB;
import com.example.bookborrowing.domain.Book;

public class BorrowBookConfirmOnClickListener implements OnClickListener {

	private int uid;
	private int bookid;
	private SQLiteDatabase db;
	private Fragment fragment;

	public BorrowBookConfirmOnClickListener(int uid, int bookid,
			SQLiteDatabase db, Fragment fragment) {
		this.uid = uid;
		this.bookid = bookid;
		this.db = db;
		this.fragment = fragment;
	}

	@Override
	public void onClick(DialogInterface dialog, int which) {
		// 检查书有没有被借走
		if (AboutDB.isBorrowed(db, bookid)) {
			Toast.makeText(fragment.getActivity(), "已经借走了", Toast.LENGTH_SHORT)
					.show();
			return;
		}
		// 插入订单
		AboutDB.insertOrder(db, uid, bookid);
		// 修改图书状态
		AboutDB.updateBook(db, bookid, Book.BORROWED);


	}
}
