package com.example.bookborrowing.listener;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.database.sqlite.SQLiteDatabase;

import androidx.fragment.app.Fragment;

import com.example.bookborrowing.db.AboutDB;
import com.example.bookborrowing.domain.Book;


public class ReturnBookConfirmOnClickListener implements OnClickListener {

	private int _id;
	private int bookid;
	private SQLiteDatabase db;
	private Fragment tabFragment;

	public ReturnBookConfirmOnClickListener(int _id, int bookid,
			SQLiteDatabase db, Fragment tabFragment) {
		this._id = _id;
		this.bookid = bookid;
		this.db = db;
		this.tabFragment = tabFragment;
	}

	@Override
	public void onClick(DialogInterface dialog, int which) {

		// 插入订单
		AboutDB.deleteOrder(db, _id);
		// 修改图书状态
		AboutDB.updateBook(db, bookid, Book.UNBORROWED);
		return;


	}
}
