package com.example.bookborrowing.fragment;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.example.bookborrowing.AddBookActivity;
import com.example.bookborrowing.R;
import com.example.bookborrowing.UpdateuserActivity;
import com.example.bookborrowing.db.AboutDB;
import com.example.bookborrowing.domain.User;
import com.example.bookborrowing.listener.ReturnBookConfirmOnClickListener;

import java.util.List;
import java.util.Map;

public class OrderFragment extends Fragment {
	SQLiteDatabase db;
	public OrderFragment() {
	}

	private Button addBookBtn, searchBookBtn;
	private EditText bookSearchText;
	private ListView listView;

	private int userid;

	public OrderFragment(int userid,
						 SQLiteDatabase db) {

		this.db= db;
		this.userid = userid;
	}

	@Override
	public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
		super.onViewCreated(view, savedInstanceState);
		Button add ,mima;
		add = view.findViewById(R.id.add);
		mima = view.findViewById(R.id.xiu);
		mima.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				FragmentTransaction transaction = getParentFragmentManager().beginTransaction();
				transaction.replace(R.id.fragment_content,new BookFragment(userid,"用户",db)).commit();
			}
		});
		add.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(getContext(), AddBookActivity.class);
				startActivity(intent);
			}
		});
		List<? extends Map<String, ?>> list = AboutDB.getOrderListById(db, userid);
		if (list.size()==0){
			mima.setVisibility(View.VISIBLE);

		}

		listView = (ListView) view.findViewById(R.id.orderListView);
		SimpleAdapter simpleAdapter = new SimpleAdapter(getContext(),
				list
				,
				R.layout.order_list_item_1, new String[]{"_id",
				"username", "bookname", "bookid"},
				new int[]{
						R.id.list_order_id, R.id.list_order_username,
						R.id.list_order_bookname, R.id.list_order_book_id});
		listView.setAdapter(simpleAdapter);
		listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
									int position, long id) {
				ListView templist = (ListView) parent;
				View mView = templist.getChildAt(position);
				TextView mTextView1 = (TextView) mView
						.findViewById(R.id.list_order_id);
				TextView mTextView2 = (TextView) mView
						.findViewById(R.id.list_order_book_id);
				TextView mTextView3 = (TextView) mView
						.findViewById(R.id.list_order_bookname);
				new AlertDialog.Builder(getActivity())
						.setTitle("要还" + mTextView3.getText().toString() + "吗")
						.setIcon(android.R.drawable.ic_dialog_info)
						.setPositiveButton(
								"确定",
								new ReturnBookConfirmOnClickListener(Integer
										.parseInt(mTextView1.getText()
												.toString()), Integer
										.parseInt(mTextView2.getText()
												.toString()), db,
										null))
						.setNegativeButton("取消", null).show();
			}
		});




		List<User> list11 = AboutDB.getAllUser(db);
		String name = new String();
		for (int i = 0; i < list11.size(); i++) {
			if (list11.get(i).getId()==userid){
				name = list11.get(i).getName();
				break;
			}
		}
		TextView title = view.findViewById(R.id.id);
		title.setText("用户"+name);
		String finalName = name;
		view.findViewById(R.id.mi).setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(getContext(), UpdateuserActivity.class);
				intent.putExtra("user", finalName);
				startActivity(intent);
			}
		});
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View fragView = inflater.inflate(R.layout.order_ui_content, container,
				false);
		return fragView;
	}
}
