package com.example.bookborrowing;

import android.annotation.SuppressLint;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.example.bookborrowing.db.AboutDB;
import com.example.bookborrowing.db.DataBaseHelper;

import com.example.bookborrowing.fragment.BookFragment;
import com.example.bookborrowing.fragment.HomeFragment;
import com.example.bookborrowing.fragment.OrderFragment;
import com.example.bookborrowing.fragment.Venue_browsingFragment;


public class MainActivity extends AppCompatActivity  {
	DataBaseHelper dbh = new DataBaseHelper(this);
	SQLiteDatabase db;
//	ActionBar bar;
	RadioButton r1,r2,r3,r4;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		db = dbh.getWritableDatabase();
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		Bundle b = this.getIntent().getExtras();
		String userStatus = String.valueOf(b.get("status"));
		int uid = b.getInt("uid");

		FragmentManager manager = getSupportFragmentManager();
		manager.beginTransaction().add(R.id.fragment_content,new HomeFragment()).commit();
		r1 =findViewById(R.id.r1);
		r2 =findViewById(R.id.r2);
		r3 =findViewById(R.id.r3);
		r4 =findViewById(R.id.r4);
		int a = getResources().getColor(R.color.a);
		int a1 = getResources().getColor(R.color.a1);
		r1.setBackgroundColor(a1);
		r2.setBackgroundColor(a);
		r3.setBackgroundColor(a);
		r4.setBackgroundColor(a);
		r1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Button1(1);
				FragmentManager manager = getSupportFragmentManager();
				FragmentTransaction transaction = manager.beginTransaction();
				transaction.replace(R.id.fragment_content,new HomeFragment()).commit();
			}
		});
		r2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Button1(2);

				FragmentManager manager = getSupportFragmentManager();
				FragmentTransaction transaction = manager.beginTransaction();
				transaction.replace(R.id.fragment_content,new BookFragment(uid,userStatus,db)).commit();

			}
		});
		r3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Button1(3);

				FragmentManager manager = getSupportFragmentManager();
				FragmentTransaction transaction = manager.beginTransaction();
				transaction.replace(R.id.fragment_content,new Venue_browsingFragment(uid,db)).commit();

			}
		});
		r4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Button1(4);

				FragmentManager manager = getSupportFragmentManager();
				FragmentTransaction transaction = manager.beginTransaction();
				transaction.replace(R.id.fragment_content,new OrderFragment(uid,db)).commit();

			}
		});

	}


	private  void Button1(int i){
		int a = getResources().getColor(R.color.a);
		int a1 = getResources().getColor(R.color.a1);
		switch (i)
		{
			case 1:

				r1.setBackgroundColor(a1);
				r2.setBackgroundColor(a);
				r3.setBackgroundColor(a);
				r4.setBackgroundColor(a);
				break;
			case 2:
				r1.setBackgroundColor(a);
				r2.setBackgroundColor(a1);
				r3.setBackgroundColor(a);
				r4.setBackgroundColor(a);
				break;
			case 3:
				r1.setBackgroundColor(a);
				r2.setBackgroundColor(a);
				r3.setBackgroundColor(a1);
				r4.setBackgroundColor(a);
				break;
			case 4:
				r1.setBackgroundColor(a);
				r2.setBackgroundColor(a);
				r3.setBackgroundColor(a);
				r4.setBackgroundColor(a1);
				break;
		}
	}


}
