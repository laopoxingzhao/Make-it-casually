 package com.example.bookborrowing.fragment;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import com.example.bookborrowing.R;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class Venue_browsingFragment extends Fragment {


    private  SQLiteDatabase db;
    private  int userid;



    public Venue_browsingFragment(int userid,
                                  SQLiteDatabase db) {

        this.db= db;
        this.userid = userid;
    }



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
      List<Map<String, String>> topThreeBooks1 =new LinkedList<>();
      String [] id= new String[]{"知行书店","知行书店","博雅书店","新华书店4"};
      String [] name= new String[]{"河南省南阳市镇平县杨集镇东屯村","江西省赣州市于都县新围镇新围村","江西省赣州市于都县新围镇新围村","上海市黄浦区南京东路中信泰富广场"};
      String [] author= new String[]{"9:30-20:00","1:00-20:00","8:00-20:00","9:00-21:00"};
      String [] publish= new String[]{"15898765432","15898765432","15898765432","15898765432"};

        for (int i = 0; i < id.length; i++) {
            Map<String,String> hashMap = new HashMap<String,String>();
            hashMap.put("_id",id[i]);
            hashMap.put("name",name[i]);
            hashMap.put("author",author[i]);
            hashMap.put("publish",publish[i]);
            topThreeBooks1.add(hashMap);
        }
        Log.d("TAG", topThreeBooks1.toString());
//        map.put("_id","新华书店")

        ListView bookListView1 = view.findViewById(R.id.lt);
        bookListView1.setAdapter(new SimpleAdapter(
                getContext(),topThreeBooks1 , R.layout.book_list_item_1,
                new String[] { "_id", "name", "author", "publish" },

                new int[] { R.id.list_book_name, R.id.list_book_author,
                        R.id.list_book_publish, R.id.list_book_status}));

        EditText ed= view.findViewById(R.id.ed);
        TextView id1 ,name1, author1, publish1;
        id1= view.findViewById(R.id.list_book_name);
        name1= view.findViewById(R.id.list_book_author);
        author1= view.findViewById(R.id.list_book_publish);
        publish1= view.findViewById(R.id.list_book_status);

        ed.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                for (int i = 0; i < id.length; i++) {
                    if (id[i].contains(s.toString())) {
                        id1.setText(id[i]);
                        name1.setText(name[i]);
                        author1.setText(author[i]);
                        author1.setText(publish[i]);
                        break;
                    }else {
                        id1.setText("无");
                        name1.setText("");
                        author1.setText("");
                        author1.setText("");
                    }

                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_me, container, false);
    }
}