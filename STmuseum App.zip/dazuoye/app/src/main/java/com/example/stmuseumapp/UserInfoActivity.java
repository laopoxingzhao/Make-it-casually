package com.example.stmuseumapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.stmuseumapp.entity.User;
import com.example.stmuseumapp.utils.DBOpenHelper;

public class UserInfoActivity extends AppCompatActivity {

    TextView name;
    EditText text;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_info);
        name = findViewById(R.id.name);
        text=findViewById(R.id.updataname);
        button = findViewById(R.id.namexx);
        if (User._name!=null){
            name.setText(User._name.toString());
        }
        name.setText("未登录".toString());
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (User._name!=null){
                    String s = text.getText().toString();
                    DBOpenHelper openHelper = new DBOpenHelper(UserInfoActivity.this);
                    openHelper.updata(s,User._name);
                    Toast.makeText(UserInfoActivity.this,"修改成功",Toast.LENGTH_SHORT).show();
                    UserInfoActivity.this.finish();
                }
                else
                Toast.makeText(UserInfoActivity.this,"请先登录",Toast.LENGTH_SHORT).show();
            }
        });

    }
}