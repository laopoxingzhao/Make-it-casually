package com.example.stmuseumapp.fragment;


import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager2.widget.ViewPager2;

import com.example.stmuseumapp.Classname.Adapter.ViewPagerAdapter;
import com.example.stmuseumapp.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class oneFragment extends Fragment {
    private List<Integer> imageList = new ArrayList<>();
    private ViewPager2 viewPager2;
    private TextView mainTv;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.shouye, container, false);
        initImage();
         viewPager2 = view.findViewById(R.id.viewpager);
        ViewPagerAdapter viewPagerAdapter = new ViewPagerAdapter(imageList);
        viewPager2.setAdapter(viewPagerAdapter);
        uiHandle.sendEmptyMessageDelayed(2, 3000);
        ImageButton imageButton1=view.findViewById(R.id.imageButton3);
        imageButton1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                FragmentTransaction fragmentTransaction1 = getParentFragmentManager().beginTransaction();
                Fragment fragment= new nineFragment();
                fragmentTransaction1.addToBackStack(null).replace(R.id.content_layout, fragment);
                fragmentTransaction1.commit();
                return false;
            }
        });
        ImageButton imageButton2=view.findViewById(R.id.imageButton);
        imageButton2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                FragmentTransaction fragmentTransaction = getParentFragmentManager().beginTransaction();
                Fragment fragment1= new threeFragment();
                fragmentTransaction.addToBackStack(null).replace(R.id.content_layout, fragment1);
                fragmentTransaction.commit();
                return false;
            }
        });
        ImageButton imageButton3=view.findViewById(R.id.imageButton2);
        imageButton3.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                FragmentTransaction fragmentTransaction1 = getParentFragmentManager().beginTransaction();
                Fragment fragment2 = new twoFragment();
                fragmentTransaction1.addToBackStack(null).replace(R.id.content_layout, fragment2);
                fragmentTransaction1.commit();

                return  false;
            }
        });
        mainTv = view.findViewById(R.id.mainTv);
        new TimeThread().start();
        return view;
    }

    /**
     *  向轮播图添加佳图片
     */
    private void initImage() {
        imageList.add(R.drawable.banner1);
        imageList.add(R.drawable.banner2);
        imageList.add(R.drawable.banner3);
//
    };
    public class TimeThread extends Thread{
        @Override
        public void run() {
            super.run();
            do{
                try {
                    Thread.sleep(1000);
                    Message msg = new Message();
                    handler.sendMessage(msg);
                    msg.what=1;

                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }while (true);

        }
    }
    private Handler handler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(Message msg) {
            switch (msg.what){
                case 1:
                    mainTv.setText(new SimpleDateFormat("HH:mm:ss").format(new Date(System.currentTimeMillis())));
                    break;

            }
            return false;
        }
    });
    private Handler uiHandle = new Handler(new Handler.Callback() {

        @Override
        public boolean handleMessage(Message message) {
            switch (message.what) {
                case 2:
                    viewPager2.setCurrentItem(viewPager2.getCurrentItem() + 1);
                    uiHandle.sendEmptyMessageDelayed(2, 3000);
                    break;
                default:
                    break;
            }
            return false;

        }

    });

}


