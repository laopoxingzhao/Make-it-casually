package com.example.stmuseumapp.fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TabHost;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.example.stmuseumapp.R;

import androidx.fragment.app.Fragment;

import java.util.ArrayList;
import java.util.HashMap;

//展览
public class twoFragment extends Fragment {
    ArrayList<HashMap<String, Object>> maps = new ArrayList<HashMap<String, Object>>();
    String [] title = new String[]{"李冰文化之旅","冬日泡温泉","摘猕猴挑"};
    int[] img={R.drawable.quan,R.drawable.zhai,R.drawable.libing};
    String [] content = new String[]{"时间：每年农历6月24日" +
            "中国·都江堰李冰文化旅游节”在世界遗产都江堰开幕，在长达一周的“旅游节”中，都江堰风景区将推出各种精" +
            "彩的活动邀请游客参与，让游客们在炎炎夏日中感受到都江堰水的清凉。" +
            "每年农历6月24日，正值鸟语花香之时，受到都江堰思泽的人们纷纷走出家门，扶老携幼，来到二王庙焚香祭祀、怀念都江堰的创始人李冰。届" +
            "时二王庙人潮涌动，热闹非凡。",
            "冬日泡温泉到都江堰”，温泉旅游节让更多的游客领略到养生的真谛，感受" +
                    "到生命的精彩，体会到生活的幸福。" +
                    "都江堰一青城山作为龙门山旅游开发带的重要组成部分，将在未来的四川川旅" +
                    "游发展战略上占据重要地位。青城山道温泉是大自然对都江堰市的思赐，是道文" +
                    "化与水文化相互侵润的结果。经过都江堰景区的深度开发和打造，已经成为都江" +
                    "堰旅游里一个独特的创新文化品牌。",
            "龙门山脉一带是世界公认的猕猴桃最佳适宜种植区，在资源潜力和上市" +
                    "时间上都可与新西兰形成竞争力。国际猕猴桃节就是为了让成都猕猴桃叫响" +
                    "全世界，你猴桃节的主题一”多彩猕猴桃让世界共享成都味道。"
    };
    private ArrayList<HashMap<String, Object>> data;
    private int[] imgs={R.drawable.tao,R.drawable.chuanqong,R.drawable.larou,R.drawable.zhusun,R.drawable.chaye};
    private String[] tv1={"都江堰猕猴桃"," 川川芎和三木药材","青城山老腊肉 ","都江堰方竹笋" , "都江堰茶叶 "};
    private  String[] tv4={"都江堰市八十年代初由新西兰引入“海沃特“猕猴桃，经过近二十年的发展，现已成为全国最大的“海沃特“商品基地。一.产品介绍1200年前，青城道家以猕猴桃为主要原料，配以青城山特有矿泉水，采用道家传统方略精制酿造出“洞天乳酒”，集独特的风味和道家养生文化于一身，成为“青城四绝”之首",
            "位于青藏高原与川西平原交界处的都江堰，因其独特多样的地形气候自古以来使盛产药材，被称作“天府药源”，其出产的数百种药材中，以川芎、三木药材最为有名，川芎活血行气，杜仲理气补血，黄柏泻火解毒，厚朴下气平喘，是不可多得的绿色药材之一。",
            "不是所有腊肉都能叫做“青城山老腊肉“”，都江堰人对腊肉有着一种挑" +
                    "剔的情结一猎需要在山间野放慢养一年以上；腌制需要以山泉洗净置陶" +
                    "缸腌透滴干；熏制需要用青冈柴、杉木柴、香椿柴、柏枝慢熏半月以上：" +
                    "所出的老腊肉外观呈黑黄色，层次分明、肉皮金黄，瘦肉切开呈玫瑰色，" +
                    "这是时光的恩赐，必然弥足珍贵。","都江堰方竹笋为都江堰市优良乡土竹种，因发笋早、笋期长、笋肉细腻、质地脆嫩、口感好、营养丰富，广受当地群众和消费者喜爱。都江堰方竹现有面积1487公顷，是都江堰市农产业重点发展品种。都江堰方竹笋列入国家农产品地理标志登记产品，将进一步提升都江堰方竹笋知名度，有利于促进方竹笋的规模化、标准化发展，有利于带动竹农增收和培育地方经济新的增长点。蔬菜地域范围都江堰方竹笋农产品地理标志的保护范围为：都江堰市向峨乡、大观镇、青城山镇、中兴镇、玉堂镇、蒲阳镇、灌口镇、紫坪铺镇、虹口乡、龙池镇、天马镇、胥家镇、崇义镇、巨源镇、幸福镇、柳街镇、安龙镇、石羊镇、翠月湖镇等19个乡镇。地理坐标为：东经103°25′42″-103°47′0″，北纬31°44′54″-31°02′9″，西、北连汶川县，南接崇州市",
            "都江堰茶叶茶叶地域范围都江堰茶叶农产品地理标志的保护范围为：都江堰市向峨乡、大观镇、青城山镇、中兴镇、玉堂镇、蒲阳镇、灌口镇、紫坪铺镇、虹口乡、龙池镇、天马镇、胥家镇等12个乡镇。"};
    private final String IMG1 = "img1";
    private final String TV1 = "tv1";

    private final String TV6 = "tv6";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.two_layout,container,false);
        View tab1=inflater.inflate(R.layout.tabstyle,null);
        TextView text1=(TextView) tab1.findViewById(R.id.tab_label);
        text1.setText("吃");
        View tab2=inflater.inflate(R.layout.tabstyle,null);
        TextView text2=(TextView) tab2.findViewById(R.id.tab_label);
        text2.setText("住");
        View tab3=inflater.inflate(R.layout.tabstyle,null);
        TextView text3=(TextView) tab3.findViewById(R.id.tab_label);
        text3.setText("行");
        View tab4=inflater.inflate(R.layout.tabstyle,null);
        TextView text4=(TextView) tab4.findViewById(R.id.tab_label);
        text4.setText("购");

        View tab5=inflater.inflate(R.layout.tabstyle,null);
        TextView text5=(TextView) tab5.findViewById(R.id.tab_label);
        text5.setText("娱");


        TabHost th1=view.findViewById(R.id.tabhost1);
        th1.setup();
        th1.addTab(th1.newTabSpec("tab1").setIndicator(tab1).setContent(R.id.tab1));
        th1.addTab(th1.newTabSpec("tab2").setIndicator(tab2).setContent(R.id.tab2));
        th1.addTab(th1.newTabSpec("tab3").setIndicator(tab3).setContent(R.id.tab3));
        th1.addTab(th1.newTabSpec("tab4").setIndicator(tab4).setContent(R.id.tab4));
        th1.addTab(th1.newTabSpec("tab5").setIndicator(tab5).setContent(R.id.tab5));





        ListView list5 = view.findViewById(R.id.list5);
        SimpleAdapter simpleAdapter1=new SimpleAdapter(
                getContext(),
                maps,
                R.layout.list_item3,
                new String[]{IMG1,TV1,TV6},
                new int[]{R.id.im1, R.id.te1, R.id.te6}
                );


            initData();
            list5.setAdapter(simpleAdapter1);
        //
        ListView listView=view.findViewById(R.id.listview3);
        SimpleAdapter simpleAdapter=new SimpleAdapter(
                getContext(),
                data,
                R.layout.list_item3,
                new String[]{IMG1,TV1,TV6},
                new int[]{R.id.im1, R.id.te1, R.id.te6});
        listView.setAdapter(simpleAdapter);

        return view;
    }
    private void initData(){
        data=new ArrayList<HashMap<String, Object>>();
        for(int i=0;i<imgs.length;i++){
            HashMap<String,Object> map=new HashMap<String,Object>();
            map.put(IMG1,imgs[i]);
            map.put(TV1,tv1[i]);
            map.put(TV6,tv4[i]);
            data.add(map);
        }
        for (int i = 0; i <img.length; i++) {
            HashMap<String,Object> map=new HashMap<String,Object>();
            map.put(IMG1,img[i]);
            map.put(TV1,title[i]);
            map.put(TV6,content[i]);
            maps.add(map);
        }
    }

}

