package com.example.stmuseumapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.stmuseumapp.entity.User;
import com.example.stmuseumapp.fragment.fiveFragment;
import com.example.stmuseumapp.utils.DBOpenHelper;

import java.util.ArrayList;

public class LoginActivity extends AppCompatActivity {
private EditText user;
private EditText pwd;
private ImageView tou;
private Button deng;
private Button zhu;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_denglu);
        user=findViewById(R.id.user);
        pwd=findViewById(R.id.password);
        deng=findViewById(R.id.button);
        deng.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                String s = user.getText().toString().trim();
                String W = pwd.getText().toString().trim();
                if (s.isEmpty() || W.isEmpty()) {
//                    Log.e("aaa",s+W);
                    Toast.makeText(LoginActivity.this, "按要求输入", Toast.LENGTH_SHORT).show();

                } else {
                    Intent intent = new Intent(LoginActivity.this, fiveFragment.class);
                    DBOpenHelper dbOpenHelper = new DBOpenHelper(LoginActivity.this);
                    ArrayList<User> data = dbOpenHelper.getAllData();//data为获取的user表内的user信息
                    Log.e("list", String.valueOf(data));
                    for (int i = 0; i < data.size(); i++) {//遍历比较
                        User user = data.get(i);//获取data里的第i个user信息
                        if (s.equals(user.getName()) && W.equals(user.getPassword())) {
                            //将信息与输入的信息进行对比
                            Toast.makeText(LoginActivity.this, "登录成功", Toast.LENGTH_SHORT).show();
                            startActivity(intent);
                            User._name = user.getName();

                            LoginActivity.this.finish();
                            break;

                        }
                    }
                    Toast.makeText(LoginActivity.this, "登录失败", Toast.LENGTH_SHORT).show();


                }
            }});
        zhu = findViewById(R.id.button2);
        zhu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(intent1);
                LoginActivity.this.finish();
            }
        });

    }
}
