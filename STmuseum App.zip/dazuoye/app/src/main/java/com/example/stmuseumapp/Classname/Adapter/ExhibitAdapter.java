package com.example.stmuseumapp.Classname.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.stmuseumapp.Classname.Exhibit;
import com.example.stmuseumapp.R;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

class ExhibitViewHolder extends RecyclerView.ViewHolder{
    ImageView exhibitImg;
   TextView exhibitName;

    public ExhibitViewHolder (View view)
    {
        super(view);
        exhibitImg =  view.findViewById(R.id.exhibitImg);
     exhibitName = view.findViewById(R.id.exhibitName);
    }

}

public class ExhibitAdapter extends RecyclerView.Adapter<ExhibitViewHolder> {
    // 展示的数据源
    private List<Exhibit> exhibitList1;

    // 构造方法传入
    public ExhibitAdapter(List<Exhibit> exhibitList1){
        this.exhibitList1 = exhibitList1;
    }

@NonNull
 @Override
    public ExhibitViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_exhibit,parent,false);
    ExhibitViewHolder exhibitHolder = new ExhibitViewHolder(view);
        exhibitHolder.exhibitImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int position = exhibitHolder.getAdapterPosition();
               Exhibit exhibit=exhibitList1.get(position);
                Toast.makeText(view.getContext(), "点击的展品是：" + exhibit.getName(), Toast.LENGTH_SHORT).show();
            }
        });

        return exhibitHolder;
    }

@Override
    public void onBindViewHolder(@NonNull ExhibitViewHolder holder, int position) {
        Exhibit exhibit=exhibitList1.get(position);
        holder.exhibitImg.setImageResource(exhibit.getImaeId());
        holder.exhibitName.setText(exhibit.getName());
    }

    @Override
    public int getItemCount() {

        return exhibitList1.size();
    }
}
