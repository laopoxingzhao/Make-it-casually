package com.example.stmuseumapp.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.example.stmuseumapp.R;

public class nineFragment extends Fragment {
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_yuyue, container, false);
        EditText ed1=view.findViewById(R.id.ed1);
        EditText ed2=view.findViewById(R.id.ed2);
        EditText ed3=view.findViewById(R.id.ed3);
        Button button=view.findViewById(R.id.bt);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               String s = ed1.getText().toString().trim();
               String a=ed2.getText().toString().trim();
               String d=ed3.getText().toString().trim();
                if(s.equals("")&&a.equals("")&&ed3.equals("")){
                Toast.makeText(
                        requireContext().getApplicationContext(),
                        "预约失败",Toast.LENGTH_SHORT).show();
            }else{
                Toast.makeText(requireContext().getApplicationContext(),
                        "预约成功",Toast.LENGTH_SHORT).show();
            }
        }
        });
        Button button1=view.findViewById(R.id.bt1);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentTransaction fragmentTransaction = getParentFragmentManager().beginTransaction();
                Fragment fragment= new oneFragment();
                fragmentTransaction.addToBackStack(null).replace(R.id.content_layout, fragment);
                fragmentTransaction.commit();
            }
        });
        return  view;
    }
}
