package com.example.stmuseumapp.fragment;
import androidx.annotation.NonNull;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.example.stmuseumapp.LoginActivity;
import com.example.stmuseumapp.R;
import com.example.stmuseumapp.UserInfoActivity;
import com.google.android.material.navigation.NavigationView;

public class fiveFragment extends AppCompatActivity {
    private FragmentTransaction transaction;
    private RadioButton rb1;
    RadioButton rb2;
    RadioButton rb3;
    RadioButton rb4;
    private ImageButton get,imageButton2;
    private DrawerLayout drawerLayout;
    private Fragment fragmentone, fragmenttwo, fragmentthree, fragmentfour;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main1);
        drawerLayout = findViewById(R.id.drawlayout);
        NavigationView navigationView = (NavigationView) findViewById(R.id.navigationview);
        navigationView.setItemIconTintList(null);
        imageButton2 = findViewById(R.id.imageButton2);
        imageButton2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
            drawerLayout.openDrawer(GravityCompat.END);
                return false;
            }
        });
        get = findViewById(R.id.imageButton);
        get.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                Intent intent = new Intent(fiveFragment.this, LoginActivity.class);
                startActivity(intent);
                return false;
            }
        });
        RadioGroup group = findViewById(R.id.group);
        rb1 = findViewById(R.id.radioButton);
        rb2 = findViewById(R.id.radioButton2);
        rb3 = findViewById(R.id.radioButton3);
        rb4 = findViewById(R.id.radioButton4);
        transaction = getSupportFragmentManager().beginTransaction();

        if (fragmentone == null) {
            fragmentone = new oneFragment();
            transaction.add(R.id.content_layout, fragmentone);
        }
        if (fragmenttwo == null) {
            fragmenttwo = new twoFragment();
            transaction.add(R.id.content_layout, fragmenttwo);
        }
        if (fragmentthree == null) {
            fragmentthree = new threeFragment();
            transaction.add(R.id.content_layout, fragmentthree);
        }
        if (fragmentfour == null) {
            fragmentfour = new fourFragment();
            transaction.add(R.id.content_layout, fragmentfour);
        }


        transaction.show(fragmentone);
        transaction.commit();

        group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int checkedId) {
                if (rb1.isChecked()) {
                    getSupportFragmentManager().beginTransaction()
                            .replace(R.id.content_layout, fragmentone)
                            .addToBackStack(null)
                            .commit();
                }
                if (rb2.isChecked()) {
                    getSupportFragmentManager().beginTransaction()
                            .replace(R.id.content_layout, fragmenttwo)
                            .addToBackStack(null)
                            .commit();
                }
                if (rb3.isChecked()) {
                    getSupportFragmentManager().beginTransaction()
                            .replace(R.id.content_layout, fragmentthree)
                            .addToBackStack(null)
                            .commit();
                }
                if (rb4.isChecked()) {
                    getSupportFragmentManager().beginTransaction()
                            .replace(R.id.content_layout, fragmentfour)
                            .addToBackStack(null)
                            .commit();
                }

            }
        });
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
switch (item.getItemId()){
    case R.id.daohang1:  getSupportFragmentManager().beginTransaction()
            .replace(R.id.content_layout, fragmentone)
            .addToBackStack(null)
            .commit();

        break;
    case R.id.daohang2:   getSupportFragmentManager().beginTransaction()
            .replace(R.id.content_layout, fragmenttwo)
            .addToBackStack(null)
            .commit();

        break;
    case R.id.daohang3:
        Intent intent = new Intent(fiveFragment.this, UserInfoActivity.class);
        startActivity(intent);


        break;
    case R.id.daohang6:  getSupportFragmentManager().beginTransaction()
            .replace(R.id.content_layout, fragmentthree)
            .addToBackStack(null)
            .commit();

        break;
    case R.id.daohang7:  getSupportFragmentManager().beginTransaction()
            .replace(R.id.content_layout, fragmentfour)
            .addToBackStack(null)
            .commit();
        break;
}
                return false;
            }
        });
    }


}