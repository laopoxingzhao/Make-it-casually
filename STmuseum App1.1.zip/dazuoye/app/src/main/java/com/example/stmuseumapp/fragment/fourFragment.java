package com.example.stmuseumapp.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TabHost;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.example.stmuseumapp.R;



import java.util.ArrayList;
import java.util.HashMap;


//咨询
public class fourFragment extends Fragment {
    private ArrayList<HashMap<String, Object>> data;
    String[] dates={"01","02","03","04","05"};
    String[] times={"2022.07","2022.07","2022.06","2022.06","2022.04"};
    String[] items={"2023成都双遗马拉松燃爆都江堰，最美赛道带你跑进春日画境~","深藏不露！千年古道关隘、川派隐秀古园......水灵妹带你解锁8处惊艳了时光的古建筑~",
            "免费冷门耍法！都江堰人的“三味书屋”，深藏山林深处、静立闹市之中......解锁夏日逾秋的书香慢生活～",
            "万元大奖！青城山—都江堰景区摄影、短视频大赛火热持续中！"};
    private final String DATE = "date";
    private final String TIME = "time";
    private final String ITEM = "item";
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.four_layout,container,false);
        View tab1=inflater.inflate(R.layout.tabstyle,null);
        TextView text1=(TextView) tab1.findViewById(R.id.tab_label);
        text1.setText("信息公开");
        View tab2=inflater.inflate(R.layout.tabstyle,null);
        TextView text2=(TextView) tab2.findViewById(R.id.tab_label);
        text2.setText("新闻公告");
        View tab3=inflater.inflate(R.layout.tabstyle,null);
        TextView text3=(TextView) tab3.findViewById(R.id.tab_label);
        text3.setText("通知公告");
        TabHost th3=view.findViewById(R.id.tabhost3);
        th3.setup();
        th3.addTab(th3.newTabSpec("").setIndicator(tab1).setContent(R.id.tab1));
        th3.addTab(th3.newTabSpec("").setIndicator(tab2).setContent(R.id.tab2));
        th3.addTab(th3.newTabSpec("").setIndicator(tab3).setContent(R.id.tab3));
        FragmentTransaction transaction=getChildFragmentManager().beginTransaction();
        Fragment fragment;
        fragment= new sixFrament();
        transaction.add(R.id.tab1,fragment);
        Fragment fragment1;
        fragment1=new eightFragment();
        transaction.add(R.id.tab3,fragment1);
        transaction.commit();
        initData();

        ListView listView=view.findViewById(R.id.listview1);
        SimpleAdapter simpleAdapter=new SimpleAdapter(getContext(), data,R.layout.list_item,new String[]{DATE,TIME,ITEM},new int[]{R.id.tv1,R.id.tv2,R.id.tv3});
        listView.setAdapter(simpleAdapter);
        return view;
    }
    private void initData(){
        data=new ArrayList<HashMap<String, Object>>();
        for(int i=0;i<items.length;i++){
            HashMap<String,Object> map=new HashMap<String,Object>();
            map.put(DATE,dates[i]);
            map.put(TIME,2022.11);
            map.put(ITEM,items[i]);
            data.add(map);
        }

    }

}


