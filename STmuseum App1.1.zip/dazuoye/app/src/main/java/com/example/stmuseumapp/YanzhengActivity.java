package com.example.stmuseumapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class YanzhengActivity extends AppCompatActivity implements  View.OnClickListener{
    private EditText phone, yanzhenma;
    private Button login,yanzhen;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_yanzheng);
        phone=findViewById(R.id.phone);
        yanzhenma=findViewById(R.id.yanzhenma);
        yanzhen=findViewById(R.id.yanzhen);
        login=findViewById(R.id.button4);
        yanzhen.setOnClickListener(this);
        login.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {

    }

}