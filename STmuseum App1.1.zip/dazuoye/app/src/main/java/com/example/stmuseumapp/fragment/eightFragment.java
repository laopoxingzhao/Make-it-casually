package com.example.stmuseumapp.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import com.example.stmuseumapp.R;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;
import java.util.HashMap;

public class eightFragment extends Fragment {
        private ArrayList<HashMap<String, Object>> data;
        private final String DATE = "date";
        private final String TIME = "time";
        private final String ITEM = "item";

        private String[] dates={"01","02","03","04"};
        private  String[] times={"11月10日","10月5日","7月2日","6月10日"};
        private  String[] items={"年末豪礼 | 青城山-都江堰景区12月整月免票 ！戳这里了解预约详情~" ,
                "全国旅行商“大咖”齐聚都江堰，共商旅游发展",
                "立足国际精品景区打造，青城山—都江堰景区与携程签署“IBU”战略合作协议\n",};
@Nullable
@Override
public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState){
        View view=inflater.inflate(R.layout.rab4tab3,container,false);
        initData();
        ListView listView=view.findViewById(R.id.listview2);
        SimpleAdapter simpleAdapter=new SimpleAdapter(getContext(), data,R.layout.list_item1,
                new String[]{DATE,TIME,ITEM},
                new int[]{R.id.t1,
                        R.id.t2,
                        R.id.t3});
        listView.setAdapter(simpleAdapter);
        return  view;
        }
        private void initData(){
                data=new ArrayList<HashMap<String, Object>>();
                for(int i=0;i<items.length;i++){
                        HashMap<String,Object> map=new HashMap<String,Object>();
                        map.put(DATE,dates[i]);
                        map.put(TIME,times[i]);
                        map.put(ITEM,items[i]);
                        data.add(map);
                }

        }
}