package com.example.stmuseumapp.entity;

public class Exhibit {
    private String name;
    private int imageId;

    public Exhibit(String name, int imageId){
        this.name = name;
        this.imageId = imageId;

    }
    public String getName() {
        return name;
    }
    public int getImaeId() {
        return imageId;
    }
}
