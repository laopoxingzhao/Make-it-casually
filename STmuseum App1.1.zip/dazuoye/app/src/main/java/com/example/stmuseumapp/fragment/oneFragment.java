package com.example.stmuseumapp.fragment;


import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager2.widget.ViewPager2;

import com.example.stmuseumapp.Adapter.ViewPagerAdapter;
import com.example.stmuseumapp.R;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class oneFragment extends Fragment {
    private List<Integer> imageList = new ArrayList<>();
    private ViewPager2 viewPager2;
    private TextView mainTv;
    Button imageButton4;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.shouye, container, false);
        initImage();
        imageButton4 = view.findViewById(R.id.imageButton4);
        imageButton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dialog dialog = new Dialog(getContext()) ;
                LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                View dialogView = inflater.inflate(R.layout.dialog, null, false);
                dialog.addContentView(dialogView, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT));
                dialog.show();
            }
        });


        viewPager2 = view.findViewById(R.id.viewpager);
        ViewPagerAdapter viewPagerAdapter = new ViewPagerAdapter(imageList);
        viewPager2.setAdapter(viewPagerAdapter);
        uiHandle.sendEmptyMessageDelayed(2, 3000);
        Button imageButton1=view.findViewById(R.id.imageButton3);
        imageButton1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                FragmentTransaction fragmentTransaction1 = getParentFragmentManager().beginTransaction();
                Fragment fragment= new nineFragment();
                fragmentTransaction1.addToBackStack(null).replace(R.id.content_layout, fragment);
                fragmentTransaction1.commit();
                return false;
            }
        });

        new TimeThread().start();
        return view;
    }

    /**
     *  向轮播图添加佳图片
     */
    private void initImage() {
        imageList.add(R.drawable.zc01);
        imageList.add(R.drawable.banner);
        imageList.add(R.drawable.banner3);
//
    };
    public class TimeThread extends Thread{
        @Override
        public void run() {
            super.run();
            do{
                try {
                    Thread.sleep(1000);
                    Message msg = new Message();
                    handler.sendMessage(msg);
                    msg.what=1;

                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }while (true);

        }
    }
    private Handler handler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(Message msg) {
            switch (msg.what){
                case 1:
                    break;
            }
            return false;
        }
    });
    private Handler uiHandle = new Handler(new Handler.Callback() {

        @Override
        public boolean handleMessage(Message message) {
            switch (message.what) {
                case 2:
                    viewPager2.setCurrentItem(viewPager2.getCurrentItem() + 1);
                    uiHandle.sendEmptyMessageDelayed(2, 3000);
                    break;
                default:
                    break;
            }
            return false;

        }

    });

}


