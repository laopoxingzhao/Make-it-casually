package com.example.stmuseumapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.example.stmuseumapp.entity.User;
import com.example.stmuseumapp.utils.DBOpenHelper;

import java.util.ArrayList;
import java.util.Calendar;

public class RegisterActivity extends AppCompatActivity {
private EditText user1;
private EditText pwd1;
private Button register;
private  String seex;
private RadioButton rbman,rbwoman;
private EditText year;
private ImageView touxiang;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
      touxiang=findViewById(R.id.touxiang);
        user1=findViewById(R.id.user1);
       pwd1=findViewById(R.id.password1);
       register=findViewById(R.id.button3);
       register.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               AlertDialog.Builder builder =  new  AlertDialog.Builder(
                       RegisterActivity.this);
               builder.setTitle("用户协议");
               builder.setIcon(R.drawable.logo);
               builder.setMessage("注册新用户需接受用户协议的约束，请您认真查阅用户协议内容，并选择是否同意接受用户协议。");

               builder.setPositiveButton("同意", new DialogInterface.OnClickListener(){
                   @Override
                   public void onClick(DialogInterface dialogInterface, int which) {
                       DBOpenHelper dbOpenHelper = new DBOpenHelper(RegisterActivity.this);
                       ArrayList<User> data = dbOpenHelper.getAllData();//data为获取的user表内的user信息
                       data.forEach(s->{
                           if (s.getName().equals(user1.getText().toString().trim()) && s.getPassword().equals(pwd1.getText().toString().trim())) {//将信息与输入的信息进行对比
                             Toast.makeText(RegisterActivity.this,"已存在",Toast.LENGTH_SHORT).show();
                           } else {

                               Log.e("aaa",user1.getText().toString().trim()+"   "+pwd1.getText().toString().trim());
                               dbOpenHelper.add(user1.getText().toString().trim(),pwd1.getText().toString().trim());
                               Intent intenttologin = new Intent(RegisterActivity.this, LoginActivity.class);
                               startActivity(intenttologin);
                               RegisterActivity.this
                                       .finish();
                           }
                       });

                   }
               });

               builder.setNegativeButton("不同意", new DialogInterface.OnClickListener() {
                   @Override
                   public void onClick(DialogInterface dialogInterface, int which) {
                       Toast.makeText(RegisterActivity.this, "只有接受用户协议，才能注册新用户", Toast.LENGTH_SHORT).show();
                   }
               });

               AlertDialog dialog = builder.create();
               dialog.show();
           }
       });
      rbman=findViewById(R.id.rbman);
      rbwoman=findViewById(R.id.rbwoman);
      final RadioGroup group=findViewById(R.id.group);
      group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
          @Override
          public void onCheckedChanged(RadioGroup radioGroup, int i) {
              if(i==R.id.rbman){
                  seex=(String) rbman.getText();
              }
              if(i==R.id.rbwoman){
                  seex=(String)rbwoman.getText();
              }
          }
      });
       year=findViewById(R.id.year);
       year.setOnTouchListener(new View.OnTouchListener() {
           @Override
           public boolean onTouch(View view, MotionEvent motionEvent) {
               if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
                   showDatePickDlg();
                   return true;
               }

               return false;
           }
       });
       year.setOnFocusChangeListener(new View.OnFocusChangeListener() {
           @Override
           public void onFocusChange(View view, boolean b) {
               if (b) {
                   showDatePickDlg();
               }

           }
       });
    }
    protected void showDatePickDlg(){
        Calendar calendar=Calendar.getInstance();
        DatePickerDialog datePickerDialog = new DatePickerDialog(RegisterActivity.this, new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int month, int day) {
                RegisterActivity.this.year.setText(year + "-" + month + "-" + day);

            }
        },
                2022,10,20);
        datePickerDialog.show();
    }

}


