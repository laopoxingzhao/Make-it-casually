package com.example.stmuseumapp.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.stmuseumapp.R;

import java.util.List;

public class ViewPagerAdapter extends RecyclerView.Adapter<ViewPagerAdapter.ViewPagerHolder> {

    private List<Integer> imageList;

    public ViewPagerAdapter(List<Integer> imageList) {
        this.imageList = imageList;
    }

    @NonNull
    @Override
    public ViewPagerHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.imagepager, parent, false);

        return new ViewPagerHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewPagerHolder holder, int position) {
        holder.imagePager.setImageResource(imageList.get(position % imageList.size()));
    }

    @Override
    public int getItemCount() {
        return Integer.MAX_VALUE;
    }

    class ViewPagerHolder extends RecyclerView.ViewHolder {
        ImageView imagePager;

        public ViewPagerHolder(@NonNull View itemView) {
            super(itemView);
            imagePager = itemView.findViewById(R.id.imagepager);
        }
    }
}