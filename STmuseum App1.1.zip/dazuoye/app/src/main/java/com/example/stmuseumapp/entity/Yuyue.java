package com.example.stmuseumapp.entity;

public class Yuyue {


    private String name;
    private long phone;
    private int date;
    public Yuyue(String name, long phone, int date){
        this.name = name;
        this.phone = phone;
        this.date=date;

    }
    public String getName() {
        return name;
    }
    public long getPhone() {
        return phone;
    }
    public int getDate(){ return  date;}


}
