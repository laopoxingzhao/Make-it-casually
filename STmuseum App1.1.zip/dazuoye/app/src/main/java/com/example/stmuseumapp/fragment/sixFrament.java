package com.example.stmuseumapp.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.stmuseumapp.R;

import java.util.ArrayList;
import java.util.HashMap;

public class sixFrament extends Fragment {
    private ListView myListView;
    private String[] dates={"01","02","03","04"};
    private String[] times={"2022.07","2022.07","2022.06","2022.06"};
    private String[] items={"青城山-都江堰旅游景区文物保护管理制度","都江堰市青城山—都江堰旅游景区管理局资源保护管理制度",
            "天府青城康养休闲旅游度假区简介”，天府青城康养休闲旅游度假区简介"};
    private ArrayList<HashMap<String, Object>> data;
    private final String DATE = "date";
    private final String TIME = "time";
    private final String ITEM = "item";
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.rab4tab1, container, false);

        initData();
        myListView=view.findViewById(R.id.listview);
        SimpleAdapter simpleAdapter=new SimpleAdapter(getContext(), data,R.layout.list_item,new String[]{DATE,TIME,ITEM},new int[]{R.id.tv1,R.id.tv2,R.id.tv3});
        myListView.setAdapter(simpleAdapter);

        return view;

    }
    private void initData(){

        data=new ArrayList<HashMap<String, Object>>();

        for(int i=0;i<items.length;i++){
            HashMap<String,Object> map=new HashMap<String,Object>();
            map.put(DATE,dates[i]);
            map.put(TIME,times[i]);
            map.put(ITEM,items[i]);
            data.add(map);
        }

    }
}
