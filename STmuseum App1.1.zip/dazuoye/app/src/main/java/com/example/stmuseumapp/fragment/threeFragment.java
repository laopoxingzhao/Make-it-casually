package com.example.stmuseumapp.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.SimpleAdapter;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.example.stmuseumapp.R;

import java.util.Calendar;
//参观
public class  threeFragment extends Fragment {
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.three_layout,container,false);
        ScrollView scrollView=view.findViewById(R.id.scrollview2);
        View tab1=inflater.inflate(R.layout.tabstyle,null);
        TextView text1=(TextView) tab1.findViewById(R.id.tab_label);
        text1.setText("参观路线");
        View tab2=inflater.inflate(R.layout.tabstyle,null);
        TextView text2=(TextView) tab2.findViewById(R.id.tab_label);
        text2.setText("活动日历");
        View tab4=inflater.inflate(R.layout.tabstyle,null);
        TextView text4=(TextView) tab4.findViewById(R.id.tab_label);
        text4.setText("参观需知");

        TabHost th2=view.findViewById(R.id.tabhost2);
        th2.setup();
        th2.addTab(th2.newTabSpec("tab1").setIndicator(tab1).setContent(R.id.tab001));
        th2.addTab(th2.newTabSpec("tab2").setIndicator(tab2).setContent(R.id.tab002));
        th2.addTab(th2.newTabSpec("tab4").setIndicator(tab4).setContent(R.id.tab004));


        CalendarView calndarView=view.findViewById(R.id.calendarView3);
        calndarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
         @Override
         public void onSelectedDayChange(@NonNull CalendarView calendarView, int year, int month, int day) {
           int  month1=month+1;
             Toast.makeText(getContext(),year + "年" +  month1+ "月" + day + "日",Toast.LENGTH_SHORT).show();
         }
     });
        Button button=view.findViewById(R.id.button5);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar calendar=Calendar.getInstance();
                calendar.set(2022,10,25);
                calndarView.setDate(calendar.getTimeInMillis(),true,true);
            }
        });
        Button button1=view.findViewById(R.id.button6);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar calendar1=Calendar.getInstance();
                calendar1.set(2022,11,1);
                calndarView.setDate(calendar1.getTimeInMillis(),true,true);

            }
        });
      return view;}
}
