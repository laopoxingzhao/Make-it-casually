package com.example.museum.Fragment;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.museum.AllActivity2;
import com.example.museum.PL_Activity;
import com.example.museum.R;
import com.example.museum.RegisterActivity;
import com.example.museum.LoginActivity;

import java.util.ArrayList;


public class FifthFragment extends Fragment {

    public static ArrayList<String> arrayList = new ArrayList<String>();

    private static final int REQUEST_CODE_login = 1;//登录标识
    private static final int REQUEST_CODE_register = 0;//注册标识

    private Button F5_BT_DL, F5_BT_ZC;//注册与登录按钮
//    图片登录与注册按钮
    private ImageView DL,ZC;

    //    注册之后跳转的信息是放在这里的，显示用户名以及ID
    private TextView F5_TV_NC;//未登录的显示框
    private TextView F5_TV_ID;//用户ID的显示框
    private TextView F5_TV_DD;//订单查询

//    评论页跳转按钮
    private TextView PL;//评论

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fifth_layout, container, false);

//        默认账号密码信息插入
        arrayList.add("XSF");
        arrayList.add("202031773215");
        arrayList.add("210229");
        //设置main里面的监听器，两个跳转按钮，以及接受信息的两个文本框

        DL=view.findViewById(R.id.img_DL);
        ZC=view.findViewById(R.id.img_ZC);
        F5_TV_NC = view.findViewById(R.id.F5_TV_NC);
        F5_TV_ID = view.findViewById(R.id.F5_TV_ID);
        F5_TV_DD = view.findViewById(R.id.F5_TV_DD);//订单里面的Test View文本框

//        评论跳转按钮
        PL=view.findViewById(R.id.F5_TV_PL);
        PL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getActivity(), PL_Activity.class);
                startActivity(intent);
            }
        });

        //        步骤一：
        //从MainAcitivity跳转到loginActivity（注册界面）
        DL .setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //通过Intent实现页面跳转同时传递信息
                Intent intent = new Intent(getActivity(), LoginActivity.class);
                startActivityForResult(intent, REQUEST_CODE_login);
            }
        });
        //从MainAcitivity跳转到registerActivity（登录界面）
        ZC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), RegisterActivity.class);
                startActivityForResult(intent, REQUEST_CODE_register);
//                getActivity().startActivity(intent);
            }
        });

//        从Fragment5跳转到ALl Activity的跳转,订单查询跳转
        F5_TV_DD.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), AllActivity2.class);
                startActivity(intent);
            }
        });

        return view;
    }

        //步骤三：
    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case REQUEST_CODE_login://登录
                if (resultCode == Activity.RESULT_OK) {

//                    显示框中显示信息
                    F5_TV_NC.setText(data.getStringExtra("name"));
                    F5_TV_ID.setText(data.getStringExtra("user"));

                }
//                这个判定再登录界面就做了，不用写了
//                else{
//                    main_m1.setText("");
//                    main_m2.setText("");
//                }
                break;

            case REQUEST_CODE_register://如果是注册
                if (resultCode == Activity.RESULT_OK) {
//                    这里是直接在界面上显示的信息
                    F5_TV_NC.setText(data.getStringExtra("n"));//昵称
                    F5_TV_ID.setText(data.getStringExtra("u"));//账号

                    String n=data.getStringExtra("n");
                    String u=data.getStringExtra("u");
                    String p=data.getStringExtra("p");

//                    注册成功之前，应该是把数据录入。昵称，账户，密码一个不少(按照顺序)

                    //初始化一个账户——添加用户
                    arrayList.add(n);//昵称
                    arrayList.add(u);//账户
                    arrayList.add(p);//密码
                    Toast.makeText(getActivity(),"注册成功",Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(getActivity(),"注册失败",Toast.LENGTH_SHORT).show();
                }
                break;
            default:
                break;
        }

    }

}















//    public static ArrayList<String> arrayList=new ArrayList<String>();
//
//    private static final int REQUEST_CODE_login=1;//登录标识
//    private static final int REQUEST_CODE_register=0;//注册标识
//
//    private Button F5_RB_DL, F5_RB_ZC;//注册与登录按钮
//
//    //    注册之后跳转的信息是放在这里的，显示用户名以及ID
//    private TextView F5_TV_NC;//未登录的显示框
//    private TextView F5_TV_ID;//用户ID的显示框

//    在主界面中，只需要显示返回的数据就行了，如果注册失败或者是登录失败都不会自动返回到主界面
//    Register：注册里面，要添加新注册的昵称，账号，密码。返回到主界面再放入arrayList存储，登录的时候要比对
//    Signin：验证账号、密码登录成功则找到昵称返回昵称与账户；登录失败则清空页面，不进行页面跳转

//    一、startActivityForResult(intent, REQUEST_CODE_register);
//    二、setResult(int resultCode,Intent data);(这个是写在跳转的页面那里，包含返回的信息)
//    三、onActivityResult(int requestCode, int resultCode, @Nullable Intent data);（分别是两个界面的标识ID和传递的数据）

//    @Override
//    public void onCreate(@Nullable Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//                初始化添加一组数据
//        arrayList.add("XSF");
//        arrayList.add("202031773215");
//        arrayList.add("210229");
//        //设置main里面的监听器，两个跳转按钮，以及接受信息的两个文本框
//        F5_RB_DL = getView().findViewById(R.id.F5_RB_DL);
//        F5_RB_DL = getView().findViewById(R.id.F5_RB_ZC);
//        F5_TV_NC = getView().findViewById(R.id.F5_TV_NC);
//        F5_TV_ID = getView().findViewById(R.id.F5_TV_ID);
//        //        步骤一：
//        //从MainAcitivity跳转到loginActivity（注册界面）
//        F5_RB_DL.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                //通过Intent实现页面跳转同时传递信息
//                Intent intent = new Intent(getActivity(), SigninActivity.class);
//                startActivityForResult(intent, REQUEST_CODE_login);
//            }
//        });
//        //从MainAcitivity跳转到registerActivity（登录界面）
//        F5_RB_ZC.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent intent = new Intent(getActivity(), RegisterActivity.class);
//                startActivityForResult(intent, REQUEST_CODE_register);
//            }
//        });
//    }
//
////    @Override
////    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
////        super.onActivityResult(requestCode, resultCode, data);
////    }
//
//
//        //    步骤三：
//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//        switch (requestCode) {
//            case REQUEST_CODE_login://登录
//                if (resultCode == Activity.RESULT_OK) {
//
////                    显示框中显示信息
//                    F5_TV_NC.setText(data.getStringExtra("name"));
//                    F5_TV_ID.setText(data.getStringExtra("user"));
//
//                }
////                这个判定再登录界面就做了，不用写了
////                else{
////                    main_m1.setText("");
////                    main_m2.setText("");
////                }
//                break;
//
//            case REQUEST_CODE_register://如果是注册
//                if (resultCode == Activity.RESULT_OK) {
////                    这里是直接在界面上显示的信息
//                    F5_TV_NC.setText(data.getStringExtra("n"));//昵称
//                    F5_TV_ID.setText(data.getStringExtra("u"));//账号
//
//                    String n=data.getStringExtra("n");
//                    String u=data.getStringExtra("u");
//                    String p=data.getStringExtra("p");
//
////                    注册成功之前，应该是把数据录入。昵称，账户，密码一个不少(按照顺序)
//
//                    //初始化一个账户——添加用户
//                    arrayList.add(n);//昵称
//                    arrayList.add(u);//账户
//                    arrayList.add(p);//密码
//                    Toast.makeText(getActivity(),"注册成功",Toast.LENGTH_SHORT).show();
//                }
//                else{
//                    Toast.makeText(getActivity(),"注册失败",Toast.LENGTH_SHORT).show();
//                }
//                break;
//            default:
//                break;
//        }
//
//    }
//
//}
//
