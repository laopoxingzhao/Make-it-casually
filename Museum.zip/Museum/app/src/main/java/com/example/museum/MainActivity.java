package com.example.museum;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.museum.Fragment.FifthFragment;
import com.example.museum.Fragment.FirstFragment;
import com.example.museum.Fragment.ForthFragment;
import com.example.museum.Fragment.ThirdFragment;

public class MainActivity extends AppCompatActivity {


    private TextView tvFirstTab,tvThirdTab,tvFourthTab,tvFifthTab;//对应XML中的ID
    private Fragment fragmentFirst,fragmentThird,fragmentFourth,fragmentFifth;//创建的5个fragment
    private Fragment fragmentCurrent;//中转的fragment
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

// 初始化底部选项和第一个fragment
        initUI();
    }
    /**
     * 初始化界面
     */
//    五个底部的UI
    private void initUI(){
        tvFirstTab = findViewById(R.id.plan1);
        tvThirdTab = findViewById(R.id.plan3);
        tvFourthTab = findViewById(R.id.plan4);
        tvFifthTab = findViewById(R.id.plan5);


        tvFirstTab.setOnClickListener(this::onClick);

        tvThirdTab.setOnClickListener(this::onClick);
        tvFourthTab.setOnClickListener(this::onClick);
        tvFifthTab.setOnClickListener(this::onClick);

// 默认显示第一个fragment
// showFirstTab();
        showThirdTab();
    }

    /**
     * 显示第一个Tab
     */
    @SuppressLint("ResourceAsColor")
    private void showFirstTab(){
// 一、开启事务（transaction）    将Fragment加载到Activity中
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
// 二、添加fragment到事务
        if(fragmentFirst == null){
            fragmentFirst = new FirstFragment();
            transaction.add(R.id.content_layout, fragmentFirst);//content_layout,绑定fragment到Activity指定布局，并添加到事务
        }
// 隐藏当前fragment
        hideCurrentFragment(transaction);

// 三、事务显示指定fragment
        transaction.show(fragmentFirst);// 显示fragment
// 提交事务
        transaction.commit();
// 暂存当前fragment
        fragmentCurrent = fragmentFirst;

//        改变字体颜色
        tvFirstTab.setTextColor(Color.RED);

        tvThirdTab.setTextColor(Color.BLACK);
        tvFourthTab.setTextColor(Color.BLACK);
        tvFifthTab.setTextColor(Color.BLACK);

    }


    /**
     * 显示第三个Tab
     */

    @SuppressLint("ResourceAsColor")
    private void showThirdTab(){
        // 开启事务
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        // 判断是否为空
        if(fragmentThird == null){
            fragmentThird = new ThirdFragment();
            //添加fragment到事务
            transaction.add(R.id.content_layout, fragmentThird);
        }

        hideCurrentFragment(transaction);

        // 显示fragment
        transaction.show(fragmentThird);

        fragmentCurrent = fragmentThird;

        // 提交事务
        transaction.commit();

//        改变字体颜色吧
        tvFirstTab.setTextColor(Color.BLACK);

        tvThirdTab.setTextColor(Color.RED);
        tvFourthTab.setTextColor(Color.BLACK);
        tvFifthTab.setTextColor(Color.BLACK);

    }
    /*显示第四个*/
    @SuppressLint("ResourceAsColor")
    private void showFourthTab(){
        // 开启事务
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        // 判断是否为空
        if(fragmentFourth == null){
            fragmentFourth = new ForthFragment();
            //添加fragment到事务
            transaction.add(R.id.content_layout, fragmentFourth);
        }

        hideCurrentFragment(transaction);

        // 显示fragment
        transaction.show(fragmentFourth);

        fragmentCurrent = fragmentFourth;

        // 提交事务
        transaction.commit();

//        改变字体颜色
        tvFirstTab.setTextColor(Color.BLACK);
        tvThirdTab.setTextColor(Color.BLACK);
        tvFourthTab.setTextColor(Color.RED);
        tvFifthTab.setTextColor(Color.BLACK);

    }
    @SuppressLint("ResourceAsColor")
    private void showFifthTab(){
        // 开启事务
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        // 判断是否为空
        if(fragmentFifth == null){
            fragmentFifth = new FifthFragment();
            //添加fragment到事务
            transaction.add(R.id.content_layout, fragmentFifth);
        }
        hideCurrentFragment(transaction);
        // 显示fragment
        transaction.show(fragmentFifth);
        fragmentCurrent = fragmentFifth;
        // 提交事务
        transaction.commit();
////        这个是改变背景色，但是不是特别好看
//        改变字体颜色吧
        tvFirstTab.setTextColor(Color.BLACK);
        tvThirdTab.setTextColor(Color.BLACK);
        tvFourthTab.setTextColor(Color.BLACK);
        tvFifthTab.setTextColor(Color.RED);

    }

    /**
     * 隐藏当前fragment
     */
    private void hideCurrentFragment(FragmentTransaction transaction){

        if (fragmentCurrent != null){
            transaction.hide(fragmentCurrent);
        }

    }

    public void onClick(View view) {
        if (view.getId() == R.id.plan1){
            showFirstTab();
        }
        else if(view.getId() == R.id.plan3){
            showThirdTab();
        }else if(view.getId() == R.id.plan4){
            showFourthTab();
        }else if(view.getId()==R.id.plan5){
            showFifthTab();
        }
    }

}