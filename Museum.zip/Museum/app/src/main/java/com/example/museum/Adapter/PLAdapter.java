package com.example.museum.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.museum.PL_Activity;
import com.example.museum.R;
import com.example.museum.entity.PL;

import java.util.List;

public class PLAdapter extends ArrayAdapter<PL> {

    private int resourceId;


    public PLAdapter(PL_Activity context, int pinglun, List<PL> dataList) {
        super(context,pinglun,dataList);//当前内容/评论的XML布局/放置SQL》PL类》dataList
        resourceId=pinglun;//与pinglun页面布局绑定
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        PL pl=getItem(position);
        View view= LayoutInflater.from(getContext()).inflate(resourceId,null);
//        获取与Adapter绑定的订单界面的控件ID
        TextView plwz=(TextView) view.findViewById(R.id.pinglun_WZ);//文字评论
        TextView  plsj=(TextView)view.findViewById(R.id.pinglun_SJ);//数据评分
//        为控件填上数据，数据从PL类获得
//        就是这里，为什么我的评论只显示一条呢
        plwz.setText(pl.getPinglun());//文字评论
        plsj.setText(pl.getFenshu());//数据评分
//        返回界面
        return view;

    }
}
