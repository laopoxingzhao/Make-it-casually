package com.example.museum;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
public class space2 extends AppCompatActivity {
    public ImageView img4;//space2=>space1
    public ImageView img7;//space2=>spaceActivity
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.space2);

        img4=findViewById(R.id.space2_11);
        img4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(space2.this,Space1.class);
                startActivity(intent);
            }
        });
        img7=findViewById(R.id.space2_22);
        img7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(space2.this,SpaceActivity.class);
                startActivity(intent);
            }
        });
    }
}