package com.example.museum.SQL;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class PLDBOpenHelper extends SQLiteOpenHelper {

    //    一共三个自定义
    public PLDBOpenHelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, "pl", factory, 1);//数据库名字
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        // 创建PL表
        String sql = "CREATE TABLE IF NOT EXISTS PL(" +
                "id integer PRIMARY KEY AUTOINCREMENT," +
                "pinglun text not null," +//评论
                "fenshu text);";//分数
        sqLiteDatabase.execSQL(sql);

        //插入默认数据
        sql = "INSERT INTO PL(pinglun,fenshu)  VALUES('周末带小朋友去玩，是个溜娃好地方！','5.0')";//数据库的PL表中插入一个新增的数据
        sqLiteDatabase.execSQL(sql);
        sql = "INSERT INTO PL(pinglun,fenshu) VALUES('拍照打卡真的很不错！','4.8')";
        sqLiteDatabase.execSQL(sql);
    }

    //    数据库升级
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
//        Log.d("---wwkk--","旧版本号：" + oldVersion + "新版本号：" + newVersion);
        // 旧版本大于新版本，则不执行
        if (oldVersion > newVersion){
            return;
        }
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS dingdan");
        // 重新创建
        onCreate(sqLiteDatabase);
    }

}
