package com.example.museum;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
public class Space extends AppCompatActivity {

        public ImageView img2;//space=>space1
        public ImageView img6;//space=>spaceActivity
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.space);
        img2=findViewById(R.id.space_22);
        img2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(Space.this,Space1.class);
                startActivity(intent);
            }
        });
        img6=findViewById(R.id.space_11);
        img6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(Space.this,SpaceActivity.class);
                startActivity(intent);
            }
        });
    }
}