package com.example.museum.entity;

public class people {

    private String money;
    private String time;
    private String leibie;
    private String name;
    private String remark;
    private String num;//新增票数

    public people(){}
    public people(String money,String time,String leibie,String name,String remark,String num){
        this.money=money;
        this.time=time;
        this.leibie=leibie;
        this.name=name;
        this.remark=remark;
        this.num=num;//新增票数
    }

//    新增票数
    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public String getMoney() {
        return money;
    }

    public void setMoney(String money) {
        this.money = money;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getLeibie() {
        return leibie;
    }

    public void setLeibie(String leibie) {
        this.leibie = leibie;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    @Override
    public String toString() {
        return "people{" +
                "money='" + money + '\'' +
                ", time='" + time + '\'' +
                ", leibie='" + leibie + '\'' +
                ", name='" + name + '\'' +
                ", remark='" + remark + '\'' +
                ", num='" + num + '\'' +//新增门票数据
                '}';
    }

}
