package com.example.museum.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.museum.AllActivity2;
import com.example.museum.InActivity;
import com.example.museum.R;

public class FirstFragment extends Fragment {

//
//    下面就是onCreateView啦
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.first_layout,container,false);
        Button main_all=view.findViewById(R.id.main_all);
//        找到布局界面的按钮ID
        Button YY=view.findViewById(R.id.FIRST_BT_YY);
        YY.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2=new Intent(getActivity(), InActivity.class);//从当前的Fragment，跳转到YuYue的Activity
                startActivity(intent2);

            }
        });
        main_all.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent3=new Intent(getActivity(), AllActivity2.class);
                startActivity(intent3);
            }
        });

//        这里是onCreateView结束位置
        return view;
    }
//    有并列的方法的写在这里
}

