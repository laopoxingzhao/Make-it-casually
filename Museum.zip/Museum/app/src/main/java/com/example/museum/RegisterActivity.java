package com.example.museum;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;

import com.example.museum.Fragment.FifthFragment;

import java.util.ArrayList;
import java.util.List;

public class RegisterActivity extends AppCompatActivity {


    private Button register;//注册按钮
    private TextView TV_register;//注册文字按钮
    private Button register_back;//左上角的小图标
    private EditText register_name,register_user,register_password;//昵称、账户、密码
    private RadioButton RB1,RB2,RB3,RB4;//选择社会身份（学生等单选）
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);


//找到ID
        register=findViewById(R.id.register_button);//注册
//        TV_register=findViewById(R.id.register_TV_button);//注册文字按钮
        register_back=findViewById(R.id.tui);//左上角退出
//        找一下消息通知上面的内容的框框里面的ID
        register_name=findViewById(R.id.register_name);//昵称
        register_user=findViewById(R.id.register_user);//账号
        register_password=findViewById(R.id.register_password);//密码
        RB1=findViewById(R.id.RB_1);//单选信息
        RB2=findViewById(R.id.RB_2);
        RB3=findViewById(R.id.RB_3);
        RB4=findViewById(R.id.RB_4);



//            左上角的退出按钮：从register跳转到MainAcitivity，这里是不是要跟改为注册的主页面要符合需求一些！
        register_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Intent intent=new Intent(RegisterActivity.this, MainActivity.class);
                Intent intent=new Intent(RegisterActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
//            注册按钮的设置，设置register的点击事件
        register.setOnClickListener(new View.OnClickListener() {
//            点击按钮的时候，首先要传输信息进行简单的存储传输，但是不存入数据库，因为注册登录账号适用于购票的时候，日常浏览就不需要账号
//            点击注册之后，弄一个消息通知框，提示注册账号的相关信息
            @Override
            public void onClick(View view) {
                //根据输入框输入内容，得到注册信息
                String n=register_name.getText().toString();//昵称
                String u=register_user.getText().toString();//账户
                String p=register_password.getText().toString();//密码

                Intent intent=new Intent();
                //将信息放入Intent中
                intent.putExtra("n",n);//昵称
                intent.putExtra("u",u);//账号
                intent.putExtra("p",p);//密码，尽管返回主界面也不显示，但是需要在主界面中录入数据
                setResult(Activity.RESULT_OK,intent);//第二步骤

//                这里开始是消息通知的代码
//                一、创建管理器notificationManager
                NotificationManager notificationManager=(NotificationManager) getSystemService(NOTIFICATION_SERVICE);
//                二、创建notificationChannel
                String channelId="notif";
                String channelNAme="显示通知";
                int important=NotificationManager.IMPORTANCE_HIGH;//重要性
                NotificationChannel notificationChannel=new NotificationChannel(channelId,channelNAme,important);
                notificationManager.createNotificationChannel(notificationChannel);
//                三、创建NotificationCompat.Builder对象
                NotificationCompat.Builder builder=new NotificationCompat.Builder(RegisterActivity.this,"notif");//上一次是这里出问题了

                builder.setSmallIcon(R.drawable.f1);//icon资源不能在mipmap目录下，但是这个图标的效果没有看到
                builder.setContentTitle("注册成功");

//              把选中的爱好与性别连成一个链表
                List<String> basc=new ArrayList<String>();
                if(RB1.isChecked()){
                    basc.add("学生 ");
                }
                if(RB2.isChecked()){
                    basc.add("职场 ");
                }
                if(RB3.isChecked()){
                    basc.add("宝妈 ");
                }
                if(RB4.isChecked()){
                    basc.add("其它 ");
                }
//                显示的通知内容
                builder.setContentText(register_name.getText().toString()+"先生/女生！"+"您已成功注册账号："+
                        register_user.getText().toString()+"为您推选"+basc.toString()+"相关的信息");
                builder.setWhen(System.currentTimeMillis());
                builder.setAutoCancel(true);
//                四、调用NotificationCompat.Builder对象的build()方法
                Notification notification= builder.build();
//                五、
                notificationManager.notify(1,notification);

//                这个用于传输信息那里结束界面，第三步返回注册的主界面显示登录账户信息！
                finish();//结束当前Activity
            }
        });

    }
}