package com.example.museum;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.museum.entity.PL;
import com.example.museum.Adapter.PLAdapter;
import com.example.museum.SQL.PLDBOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class PL_Activity extends AppCompatActivity {

//    获取数据库评论和分数的数据，放入Array怎么样，和那个列表一样的
//    与Adapter的界面绑定ListVIew

    private Button FB;
    private TextView PLWZ;
    private TextView SZ;
//    定义数据库中的对象
    private PLDBOpenHelper pldbOpenHelper;//数据库
    private SQLiteDatabase dbWriter;//写
    private SQLiteDatabase dbReader;//读

//    放入数据库，List View，pinglun.xml
    private ListView listView;
    private List<PL> datalist=new ArrayList<>();

    @SuppressLint("Range")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pl);


//        数据库初始化
        pldbOpenHelper=new PLDBOpenHelper(this,"PL",null,1);//表名没有错
        dbWriter=pldbOpenHelper.getWritableDatabase();

//        点击发布评论的时候，就要往数据库插入信息
        PLWZ=findViewById(R.id.PL_TV_PLWZ);//文字
        SZ=findViewById(R.id.PL_TV_SZ);//数字
        FB=findViewById(R.id.PL_BT_FB);//发布按钮
        FB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//        点击发布评论的时候，就要往数据库插入信息
                String sql="insert into PL(" +
                        "pinglun," +
                        "fenshu) " +//003f
                        "values(?,?)";
                String zzpinglun=PLWZ.getText().toString();//获取空间里面输入的内容
                String zzfenshu=SZ.getText().toString();

                dbWriter.execSQL(sql,new Object[]{zzpinglun,zzfenshu});//写入数据库
                Toast.makeText(PL_Activity.this,"发布成功",Toast.LENGTH_SHORT).show();

            }
        });

//                添加入数据库中之后，要从数据库中获取，读出然后暂时再ListView上面
        pldbOpenHelper=new PLDBOpenHelper(this,"PL",null,1);
        listView=findViewById(R.id.PL_LV_list);//找到ListView
        dbReader=pldbOpenHelper.getReadableDatabase();
//        与适配器匹配数据
        PLAdapter adapter=new PLAdapter(PL_Activity.this,R.layout.pinglun,datalist);//这个datalist!!!!!!
        listView.setAdapter(adapter);


        Cursor cursor=dbReader.rawQuery("select * from PL",null);
        if(cursor.moveToFirst()){
            do{
                PL pl=new PL();
                pl.setPinglin(cursor.getString(cursor.getColumnIndex("pinglun")));
                pl.setFenshu("评分:"+cursor.getString(cursor.getColumnIndex("fenshu")));
                datalist.add(pl);
            }
            while (cursor.moveToNext());
        }
    }
}