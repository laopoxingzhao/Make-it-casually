package com.example.museum;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.museum.Fragment.FifthFragment;

public class LoginActivity extends AppCompatActivity {

    //    private static ArrayList<String> arrayList=new ArrayList<String>();
    private Button login;//登录按钮
    private TextView TV_login;//登录文字按钮
    private Button login_falte;//左上角的退出按钮

    private EditText login_name,login_user,login_password;//账号与密码

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signin);

        login=findViewById(R.id.login_button);//登录按钮
//        TV_login=findViewById(R.id.register_TV_button);//登录文字按钮
        login_falte=findViewById(R.id.imageView2);//左上角退出按钮
        login_user=findViewById(R.id.login_user);//账号输入框
        login_password=findViewById(R.id.login_passwrod);//密码输入框

        //退出登录界面（左上角）
        login_falte.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(LoginActivity.this,MainActivity.class);
                startActivity(intent);

            }
        });

        //登录按钮
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

//                先获取数据
                String u=login_user.getText().toString();//账户
                String p=login_password.getText().toString();//密码

//                MainActivity.arrayList.get()用这个语句调用MainActivity里面的arrayList！！
//                利用循环，验证账户密码是否配套且正确！同时再找出配套的昵称
                for(int i=0;i<FifthFragment.arrayList.size();i++){
                    if(u.equals(FifthFragment.arrayList.get(i))&&p.equals(FifthFragment.arrayList.get(i+1))){
                        Intent intent=new Intent();

//                        在这里知道了arrayList中的数据位置，再把昵称给传递过去
                        String n= FifthFragment.arrayList.get(i-1);//昵称
//                        String n=MainActivity.arrayList.get(i-1);//昵称
                        intent.putExtra("name",n);//昵称
                        intent.putExtra("user",u);//账号
                        intent.putExtra("p",p);//密码

//                        登录成功之后显示一下再跳转界面，如果登录失败那就不用跳转，清空输入框就是了
//                        Toast.makeText(com.example.shiyan6.SigninActivity.this, "登录成功", Toast.LENGTH_SHORT).show();
                        Toast.makeText(LoginActivity.this, "登录成功", Toast.LENGTH_SHORT).show();
                        setResult(Activity.RESULT_OK,intent);
                        finish();
                    }
//                    登录失败后，页面不跳转，清空输入框就是了
                    else{
//                        如果不正确的话，把登录界面输入的数据清空，也还是方便的
                        login_user.setText("");
                        login_password.setText("");
//                        Toast.makeText(SigninActivity.this, "登录失败", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

    }
}