package com.example.museum.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.museum.AllActivity2;
import com.example.museum.R;
import com.example.museum.entity.people;

import java.util.List;

public class YuyueAdapter extends ArrayAdapter<people> {

    private int resourceId;


    public YuyueAdapter(AllActivity2 context, int xiangxi, List<people> dataList) {
        super(context,xiangxi,dataList);//当前内容/订单的XML布局/放置SQL》People类》dataList
        resourceId=xiangxi;//与xiangxi页面布局绑定
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        people p=getItem(position);
        View view= LayoutInflater.from(getContext()).inflate(resourceId,null);
//        获取与Adapter绑定的订单界面的控件ID
        TextView money=(TextView) view.findViewById(R.id.m_money);//姓名
        TextView  time=(TextView)view.findViewById(R.id.m_time);//时间
        TextView  name=(TextView)view.findViewById(R.id.m_from);//证件号
        TextView remark=(TextView)view.findViewById(R.id.m_remark);//编号
        TextView  leibie=(TextView)view.findViewById(R.id.m_family);//证件类型
        TextView  num=(TextView)view.findViewById(R.id.m_num);//绑定票数,ID获取控件33
//        为控件填上数据，数据从People类获得
        money.setText(p.getMoney());//姓名
        time.setText(p.getTime());//时间
        name.setText(p.getName());//证件号
        remark.setText(p.getRemark());//编号
        leibie.setText(p.getLeibie());//证件类型
        num.setText(p.getNum());//从人类中读入数据，放置在列表中显示出来44
//        返回界面
        return view;

    }
}
