package com.example.museum;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
public class Space1 extends AppCompatActivity {
        public ImageView img3;//space1=>space2
        public ImageView img5;//space1=>space
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.space1);
        img3=findViewById(R.id.space1_22);
        img3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(Space1.this,space2.class);
                startActivity(intent);
            }
        });
        img5=findViewById(R.id.space1_11);
        img5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(Space1.this,Space.class);
                startActivity(intent);
            }
        });
    }
}