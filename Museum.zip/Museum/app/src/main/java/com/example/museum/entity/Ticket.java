package com.example.museum.entity;

public class Ticket {

    public int id;
    public String ticket;

    public Ticket(){}
    public Ticket(String ticket) {
        this.ticket = ticket;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTicket() {
        return ticket;
    }

    public void setTicket(String ticket) {
        this.ticket = ticket;
    }
}
