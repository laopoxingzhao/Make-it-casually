package com.example.museum;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.ListView;

import com.example.museum.SQL.MyDBOpenHelper;
import com.example.museum.Adapter.YuyueAdapter;
import com.example.museum.entity.people;

import java.util.ArrayList;
import java.util.List;

public class AllActivity2 extends AppCompatActivity {

    private SQLiteDatabase dbReader;
    private SQLiteDatabase dbWriter;
    private MyDBOpenHelper dbOpenHlper;
    private ListView listView;
    private List<people> dataList=new ArrayList<people>();


    @SuppressLint("Range")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all2);

        dbOpenHlper=new MyDBOpenHelper(this,"account",null,1);
        listView=findViewById(R.id.list_all);
        dbReader=dbOpenHlper.getReadableDatabase();
        YuyueAdapter adapter=new YuyueAdapter(AllActivity2.this,R.layout.xiangxi,dataList);
        listView.setAdapter(adapter);

        Cursor cursor=  dbReader.rawQuery("select * from dingdan",null);
        if (cursor.moveToFirst()){
            do{
                people sp=new people();
                sp.setMoney("+"+cursor.getString(cursor.getColumnIndex("sje")));
                sp.setLeibie("证件类型:"+cursor.getString(cursor.getColumnIndex("slb")));
                sp.setName("证件号:"+cursor.getString(cursor.getColumnIndex("sfkf")));
                sp.setRemark("联系方式:"+cursor.getString(cursor.getColumnIndex("sbz")));
                sp.setTime("参观日期:"+cursor.getString(cursor.getColumnIndex("ssj")));
                sp.setNum("票数:"+cursor.getString(cursor.getColumnIndex("num")));//把数据库中的东西，放入People类中55
                dataList.add(sp);
            }
            while (cursor.moveToNext());
        }
    }
}