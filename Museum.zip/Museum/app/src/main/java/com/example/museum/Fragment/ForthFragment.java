package com.example.museum.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.SimpleAdapter;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.museum.EatActivity;
import com.example.museum.GameActivity;
import com.example.museum.R;
import com.example.museum.SleepActivity;
import com.example.museum.SpaceActivity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//public class ForthFragment extends Fragment implements View.OnClickListener{
public class ForthFragment extends Fragment implements View.OnClickListener{
//这个继承是为了写播放器的

//    搜索框、轮播图、、Button图片组、列表展示
//    初始化数据写在这里（但是ID好像只能在onCreat里面写）
//    轮播图初始化
    private Handler handler2 = new Handler();
    private ImageView imageView2;
    private int images2[] = {
            R.drawable.aa1,R.drawable.aa4
//            R.drawable.aaa, R.drawable.t2, R.drawable.t3, R.drawable.t4
    };
    private int index2;
    private MyRunnable myRunnable2 = new MyRunnable();//这里命名重复了

    @Override
    public void onClick(View view) {
        Intent intent = null;
        if (view.getId()==R.id.radioButton10){
            intent=new Intent(getActivity(), EatActivity.class);
        } else if (view.getId()==R.id.radioButton11) {
            intent=new Intent(getActivity(), SleepActivity.class);
        }
        else
            intent=new Intent(getActivity(), SpaceActivity.class);
        startActivity(intent);
    }

    class MyRunnable implements Runnable {
        @Override
        public void run() {
            index2++;
            index2 = index2 % 2;
            imageView2.setImageResource(images2[index2]);//imageView2这个ID做错了
            handler2.postDelayed(myRunnable2, 5000);
        }
    }

//    Fragment--Activity跳转按钮初始化
//    private Button BT_TEXT;
    private RadioButton RBTZ;
//    private ImageView IMG_TEXT;//这个测试图片已经被我删除了！
    private RadioButton MWX;


    // 纵向列表展示1、资源数据
    public ListView listView3;
    int[] imgArr3={R.drawable.zixunicon,R.drawable.zixunicon,R.drawable.zixunicon};//图片资源
    String[] titleArr3={"最新！青城山—都江堰景区入园须知","免费冷门耍法！都江堰人的“三味书屋","请扩散！5月1日青城山-都江堰景区线上门票已约满"};
    String[] contenArr3={"青城山—都江堰景区欢迎您！根据最新疫情防控要求，为确保您及同行朋友都江堰之行健康安全，特向您发来最新入园温馨提示：\n" +
            "\n" +
            " 一、青城山—都江堰景区严格落实“限量、预约、错峰”要求，请提前通过青城山—都江堰景区官方微信公众号预约购票，预约成功后无需取票，刷身份证入园即可。"
            ,"    “山不在高，有仙则灵。”灵岩山的魅力更在于那些与它结缘的名人志士的动人故事。让灵岩山不再仅仅是一座山，而是成为一段封存却未被遗忘的记忆。"
            ," 今天是五一假期的第三天" +
            "\n" +
            "都江堰的好耍地可不止景区哟~" +
            "\n" +
            "去往山野之中，纵享惬意悠然，" +

            "没有眼前的苟且，只有诗和远方。" +

            "来都江堰开启一场向往的田野生活吧~"};




//    下面是onCreat方法了
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.forth_layout,container,false);

        //        轮播图
        imageView2 = view.findViewById(R.id.imageView5);//这里对应XML里面的imageView的ID
        handler2.post(myRunnable2);
        new Thread(() -> {
            try {
                Thread.sleep(5000);
                handler2.post(new Runnable() {
                    @Override
                    public void run() {
                    }
                });
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }).start();

//        跳转按钮
        RBTZ=view.findViewById(R.id.F3_RB_F4);//找到通过RadioButtom跳转的按钮的ID

        RBTZ.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getActivity(), SpaceActivity.class);
                startActivity(intent);
            }
        });
//        冥王星
        MWX=view.findViewById(R.id.F4_RB_MWX);
        MWX.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getActivity(), GameActivity.class);
                startActivity(intent);
            }
        });

        view.findViewById(R.id.F3_RB_SM).setOnClickListener(this);
        view.findViewById(R.id.F3_RB_JK).setOnClickListener(this);
        view.findViewById(R.id.radioButton8).setOnClickListener(this);
        view.findViewById(R.id.radioButton9).setOnClickListener(this);
        view.findViewById(R.id.radioButton10).setOnClickListener(this);
        view.findViewById(R.id.radioButton11).setOnClickListener(this);
        //        纵向列表展示
//        纵向列表展示2、连接XML文件的布局
        listView3=(ListView)view.findViewById(R.id.FOURTH_LV_ZX);//连接纵向的布局界面的控件ID,这个地方不能忘记改！
//        纵向列表展示3、创建适配器
        SimpleAdapter simpleAdapter3=new SimpleAdapter(getActivity(),getData3(),
                R.layout.forth_zongxiang,new String[]{"img","name","content"},//连接XML布局
                new int[]{R.id.F_ZX_IM,R.id.F_ZX_TV1,R.id.F_ZX_TV2});
        listView3.setAdapter(simpleAdapter3);//为ListView添加适配器


//        onCreat方法结束点
        return view;
    }

    //    有并列的方法请写在这里

    //    4、for循环将数据添加到LIst里面,在页面展示
    private List<? extends Map<String,?>> getData3() {
        List<Map<String,Object>> list3;
        Map<String,Object> map3;
        list3=new ArrayList<Map<String,Object>>();

        for (int i = 0; i<imgArr3.length; i++){
            map3=new HashMap<String,Object>();
            map3.put("img",imgArr3[i]);
            map3.put("name",titleArr3[i]);
            map3.put("content",contenArr3[i]);
            list3.add(map3);
        }
        return list3;
    }

}
