package com.example.museum;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class SpaceActivity extends AppCompatActivity {

    private ImageView img1;//XML页面跳转,spaceActivity=>space
    private ImageView img2;//XML页面跳转,spaceActivity=>space1
    private ImageView img3;//XML页面跳转,spaceActivity=>space2
    private Button TC;//退出按钮
//    直接在XML里面,没有Activity是不能实现控件的

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_space);

//        点击封面图片，跳转到Space界面布局
//        private ImageView img1;//XML页面跳转,spaceActivity=>space
        img1=findViewById(R.id.Space_IMG);
        img1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

//                setContentView(R.layout.space);
                Intent intent=new Intent(SpaceActivity.this,Space.class);
                startActivity(intent);
            }
        });

        img2=findViewById(R.id.Space_IMG1);
        img2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

//                setContentView(R.layout.space1);
                Intent intent=new Intent(SpaceActivity.this,Space1.class);
                startActivity(intent);
            }
        });

        img3=findViewById(R.id.Space_IMG2);
        img3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

//                setContentView(R.layout.space2);
                Intent intent=new Intent(SpaceActivity.this,space2.class);
                startActivity(intent);
            }
        });

        TC=findViewById(R.id.SPACE_TC);
        TC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(SpaceActivity.this,MainActivity.class);
                startActivity(intent);
            }
        });

//        onCreat结束点
    }
//        onCreat结束点

}