package com.example.museum.SQL;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DataDBOpenHelper extends SQLiteOpenHelper {


    public DataDBOpenHelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, "ticket", factory, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String sql = "CREATE TABLE IF NOT EXISTS ticket_data("+
                "id integer PRIMARY KEY AUTOINCREMENT,"+
                "YuPiao text not null);";
        sqLiteDatabase.execSQL(sql);
//        sql = "INSERT INTO ticket_data(YuPiao) VALUES('500')";//数据库插入一个新增的数据
//        sqLiteDatabase.execSQL(sql);
        sql = "INSERT INTO ticket_data(YuPiao) VALUES('400')";//数据库插入一个新增的数据
        sqLiteDatabase.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
        if (oldVersion > newVersion){
            return;
        }
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS ticket_data");
        // 重新创建
        onCreate(sqLiteDatabase);
    }
}
