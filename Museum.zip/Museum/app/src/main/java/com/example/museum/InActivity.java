package com.example.museum;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.DatePickerDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.museum.SQL.DataDBOpenHelper;
import com.example.museum.SQL.MyDBOpenHelper;
import com.example.museum.entity.Ticket;

import java.util.ArrayList;
import java.util.List;

public class InActivity extends AppCompatActivity {
    private EditText time,money,name,remark;
    private String num1;//购票数量001ffffffffffffffffffffffffffffffffffffff
    private Spinner lb;
    private Button bc ,qx;
    String dd;
    //数据库中的定义对象
    private SQLiteDatabase dbWriter;
    private MyDBOpenHelper dbOpenHlper;
    private DataDBOpenHelper helper;//对象
    private SQLiteDatabase writer;
    private SQLiteDatabase reader;//权限
//    选择按钮
    private RadioButton RB0,RB1,RB2,RB3,RB4,RB5;//选择购票数（单选）
    private CheckBox CB1,CB2,CB3,CB4;//与购票人关系（多选）
    private TextView NUM_GX;//更新余票数据的框框

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_in);

        helper=new DataDBOpenHelper(this,"ticket",
                null,1);
        writer = helper.getWritableDatabase();
        reader = helper.getReadableDatabase();
        Ticket t= new Ticket();
        Cursor cursor = reader.rawQuery("select * from ticket_data",null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()){
            dd = cursor.getString(1);
            cursor.moveToNext();
        }

        money=findViewById(R.id.ed_je);//姓名
        name=findViewById(R.id.ed_fkf);//证件号
        remark=findViewById(R.id.ed_bz);//联系方式
//        num1=findViewById(R.id.IN_TV_NUM);//购票数量002fffffffffffffffffffff,这个数量应该是在选项里面
//       列表信息获取

//        获取票数信息
        TextView NUM_GX=findViewById(R.id.IN_TV_NUM);

        NUM_GX.setText(dd);

        RB0=findViewById(R.id.RB0);//单选信息
        RB1=findViewById(R.id.RB1);
        RB2=findViewById(R.id.RB2);
        RB3=findViewById(R.id.RB3);
        RB4=findViewById(R.id.RB4);
        RB5=findViewById(R.id.RB5);
        CB1=findViewById(R.id.CB1);//多选信息
        CB2=findViewById(R.id.CB2);
        CB3=findViewById(R.id.CB3);
        CB4=findViewById(R.id.CB4);

        //创建数据库,如已存在则无需创建
        dbOpenHlper=new MyDBOpenHelper(this,"account",
                null,1);
        dbWriter=dbOpenHlper.getWritableDatabase();

        //设置时间
        time=findViewById(R.id.ed_sj);
        time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog datePickerDialog=
                        new DatePickerDialog(InActivity.this, new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                                Toast.makeText(getApplicationContext(),"选择日期:"+i+"年"+
                                        i1+"月"+i2+"日",Toast.LENGTH_SHORT).show();
                                String SJ=i+"年"+i1+"月"+i2+"日";
                                time.setText(i + "年/" + i1 + "月/" + i2 + "日");
                            }
                        },2022,10,29);
                datePickerDialog.show();
            }
        });

        //设置证件类型
        lb=findViewById(R.id.sp_lb);
        String[] a=getResources().getStringArray(R.array.证件类型);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_item, a);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
        lb.setAdapter(adapter);
        lb.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String[] a=getResources().getStringArray(R.array.证件类型);
                if(a[i].equals(null)==false){
                    Toast.makeText(InActivity.this,"选择了:"+a[i],Toast.LENGTH_SHORT).show();
                    String ZJ=a[i];//保存一下选择的证件类型，后面通知会用
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });



 //        保存按钮，1、增添数据，2、消息通知，3、还有就是余票数量减少
        bc=findViewById(R.id.bt_bc);
        bc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String sql="insert into dingdan(" +
                        "sje," +
                        "ssj," +
                        "slb," +
                        "sfkf," +
//                        "sbz) " +
                        "sbz," +
                        "num) " +//003fffffffffffffffffffffffffff
                        "values(?,?,?,?,?,?)";
                String amoney=money.getText().toString();
                String atime=time.getText().toString();
                String asources=lb.getSelectedItem().toString();
                String aname=name.getText().toString();
                String aremark=remark.getText().toString();
                //        获取选择的票数信息
                if(RB1.isChecked()){
                     num1="1";
                }
                if(RB2.isChecked()){
                     num1="2";
                }
                if(RB3.isChecked()){
                     num1="3";
                }
                if(RB4.isChecked()){
                     num1="4";
                }
                if(RB5.isChecked()){
                     num1="5";
                }
                String numtt=num1;
//                String numtt=num1;//004ffffffffffffffffffffff


                dbWriter.execSQL(sql,new Object[]{amoney,atime,asources,aname,aremark,numtt});//005fffffffffffffffff,numtt

                Toast.makeText(InActivity.this,"添加成功",Toast.LENGTH_SHORT).show();;


                List<String> basc2=new ArrayList<String>();

//                获取选择的购票数量，然后把剩余的票数减少，更新
                if(RB1.isChecked()){
                    int w =Integer.parseInt(NUM_GX.getText().toString())-1;//要把从getText()中获得的数据转换为INT
                    NUM_GX.setText(String.valueOf(w));//重新设置数据的时候要转化为String才能setText()
                    basc2.add("一张门票");
                    String sql1="update ticket_data set YuPiao=? where id=1";
                    writer.execSQL(sql1,new Object[]{String.valueOf(w)});
//                    NUM_GX.setText(String.valueOf(Integer.parseInt(dd)-w));
                }
                if(RB2.isChecked()){
                    int w =Integer.parseInt(NUM_GX.getText().toString())-2;
                    NUM_GX.setText(String.valueOf(w));
                    basc2.add("两张门票");
                    String sql1="update ticket_data set YuPiao=? where id=1";
                    writer.execSQL(sql1,new Object[]{String.valueOf(w)});
//                    NUM_GX.setText(String.valueOf(Integer.parseInt(dd)-w));
                }
                if(RB3.isChecked()){
                    int w =Integer.parseInt(NUM_GX.getText().toString())-3;
                    NUM_GX.setText(String.valueOf(w));
                    basc2.add("三张门票");
                    String sql1="update ticket_data set YuPiao=? where id=1";
                    writer.execSQL(sql1,new Object[]{String.valueOf(w)});
//                    NUM_GX.setText(String.valueOf(Integer.parseInt(dd)-w));
                }
                if(RB4.isChecked()){
                    int w =Integer.parseInt(NUM_GX.getText().toString())-4;
                    NUM_GX.setText(String.valueOf(w));
                    basc2.add("四张门票");
                    String sql1="update ticket_data set YuPiao=? where id=1";
                    writer.execSQL(sql1,new Object[]{String.valueOf(w)});
//                    NUM_GX.setText(String.valueOf(Integer.parseInt(dd)-w));
                }
                if(RB5.isChecked()){
                    int w =Integer.parseInt(NUM_GX.getText().toString())-5;
                    NUM_GX.setText(String.valueOf(w));
                    basc2.add("五张门票");
                    String sql1="update ticket_data set YuPiao=? where id=1";
                    writer.execSQL(sql1,new Object[]{String.valueOf(w)});
//                    NUM_GX.setText(String.valueOf(Integer.parseInt(dd)-w));
                }


//                这里写一个预约成功的消息通知
                //                这里开始是消息通知的代码
//                一、创建管理器notificationManager
                NotificationManager notificationManager=(NotificationManager) getSystemService(NOTIFICATION_SERVICE);
//                二、创建notificationChannel
                String channelId="notif";
                String channelNAme="显示通知";
                int important=NotificationManager.IMPORTANCE_HIGH;//重要性
                NotificationChannel notificationChannel=new NotificationChannel(channelId,channelNAme,important);
                notificationManager.createNotificationChannel(notificationChannel);
//                三、创建NotificationCompat.Builder对象
                NotificationCompat.Builder builder=new NotificationCompat.Builder(InActivity.this,"notif");//上一次是这里出问题了

                builder.setSmallIcon(R.drawable.f1);//icon资源不能在mipmap目录下，但是这个图标的效果没有看到
                builder.setContentTitle("注册成功");

//                显示的通知内容
                builder.setContentText(money.getText().toString()+"先生/女生！"+"您已成功预约："+basc2.toString()
                        +"请注意参观日期");
                builder.setWhen(System.currentTimeMillis());
                builder.setAutoCancel(true);
//                四、调用NotificationCompat.Builder对象的build()方法
                Notification notification= builder.build();
//                五、
                notificationManager.notify(1,notification);


            }
        });
//        取消按钮，清空所有信息
        qx=findViewById(R.id.bt_qx);
        qx.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                money.setText("");
                name.setText("");
                time.setText("");
                remark.setText("");
            }
        });
    }
}
