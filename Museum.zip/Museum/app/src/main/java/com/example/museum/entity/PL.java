package com.example.museum.entity;

public class PL {
    public int id;
    public String pinglun;
    public String fenshu;

//    构造函数
    public PL(){};
    public PL(String pinglun,String fenshu){
        this.pinglun=pinglun;
        this.fenshu=fenshu;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPinglun() {
        return pinglun;
    }

    public void setPinglin(String pinglun) {
        this.pinglun = pinglun;
    }

    public String getFenshu() {
        return fenshu;
    }

    public void setFenshu(String fenshu) {
        this.fenshu = fenshu;
    }

    @Override
    public String toString() {
        return "PL{" +
                "id=" + id +
                ", pinglun='" + pinglun + '\'' +
                ", fenshu='" + fenshu + '\'' +
                '}';
    }
}
