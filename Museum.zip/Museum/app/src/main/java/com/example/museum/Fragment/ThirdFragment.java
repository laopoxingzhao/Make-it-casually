package com.example.museum.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.SimpleAdapter;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.museum.Chushi;
import com.example.museum.InActivity;
import com.example.museum.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//首页
public class ThirdFragment extends Fragment {


//    轮播图初始化
    private Handler handler = new Handler();
    private ImageView imageView;
    private int images[] = {
           R.drawable.banner1,R.drawable.banner2
    };
    private int index;
    private MyRunnable myRunnable = new MyRunnable();

    class MyRunnable implements Runnable {
        @Override
        public void run() {
            index++;
            index = index % 2;
            imageView.setImageResource(images[index]);
            handler.postDelayed(myRunnable, 5000);
        }
    }

//    纵向列表展示1、资源数据
    public ListView listView2;
    int[] imgArr2={R.drawable.xiongmao,R.drawable.caicha};//图片资源
    String[] titleArr2={
            "在天府青城旅游和大熊猫开启旅程",
            "有一种放松叫在天府青城旅游度假区采春茶！",
            "带你去七里诗乡、万亩花田赏最美春景"};
    String[] contenArr2={
            "熊猫谷位于都江堰市玉堂镇白马村，空气洁净，水质优良，走进熊猫谷，亲近大熊猫，破解大熊猫与都江堰的不解之缘。这里的熊猫显得更为慵懒与乖萌哟~这里绿树成荫，翠竹葱茏，鸟语花香，空气清新。在这里能独享与熊猫出现在同一画面的满足感，让你与大熊猫和大自然来一次亲密接触。",
            "“因堰而名，因水而兴”，都江堰这方水土不仅养人，还孕育出属于都江堰人的生活情调，而这其中必不可少的是茶.去到出都江堰好茶的山坡、谷地，享受优越的自然环境，顺便品读道教文化，快哉~去到出都江堰好茶的山坡、谷地，享受优越的自然环境，顺便品读道教文化，快哉~",
            "诗意春天“驾到”，你还不知道去哪里耍？都江堰市重磅打造的“踏青之旅·都江堰美丽乡村假日游”今日“汹涌”推出，千万别挑花眼哦！此次都江堰精心打造的36条精品旅游线路，将青城山、都江堰景区之外的都江堰市众多美景、美食“一网打尽”。春天来了，我在都江堰等您哦",
    };
    String[] dataArr2={"30min","40min","30min","30min"};


//    生命科学Radio Button跳转
    private RadioButton SM;
//    健康生活跳转
    private  RadioButton JK;

//    已经是相当于Activity里面的那个了
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.third_layout,container,false);
//        轮播图
        imageView = view.findViewById(R.id.imageView);
        handler.post(myRunnable);
        new Thread(() -> {
            try {
                Thread.sleep(5000);
                handler.post(new Runnable() {
                    @Override


                    public void run() {
                    }
                });
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }).start();

//        纵向列表展示2、连接XML文件的布局
        listView2=(ListView)view.findViewById(R.id.THIRD_LV_ZX);//连接纵向的布局界面
//        纵向列表展示3、创建适配器
        SimpleAdapter simpleAdapter2=new SimpleAdapter(getActivity(),getData2(),
                R.layout.third_zongxiang,new String[]{"img","name","content","data"},
                new int[]{R.id.ZX_IM_TP,R.id.F_ZX_TV1,R.id.F_ZX_TV2,R.id.F_ZX_TV3});
        listView2.setAdapter(simpleAdapter2);//为ListView添加适配器

//    门票预约 Button跳转
        SM=view.findViewById(R.id.F3_RB_SM);
        SM.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2=new Intent(getActivity(), InActivity.class);//从当前的Fragment，跳转到YuYue的Activity
                startActivity(intent2);
            }
        });
//        健康生活，跳转
        JK=view.findViewById(R.id.F3_RB_JK);
        JK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getActivity(), Chushi.class);
                startActivity(intent);
            }
        });
//        onCreat结束位置
        return view;
    }

    //    4、for循环将数据添加到LIst里面
    private List<? extends Map<String,?>> getData2() {
        List<Map<String,Object>> list2;
        Map<String,Object> map2;
        list2=new ArrayList<Map<String,Object>>();

        for (int i = 0; i<imgArr2.length; i++){
            map2=new HashMap<String,Object>();
            map2.put("img",imgArr2[i]);
            map2.put("name",titleArr2[i]);
            map2.put("content",contenArr2[i]);
            map2.put("data",dataArr2[i]);
            list2.add(map2);
        }
        return list2;
    }

}
