package com.example.museum.SQL;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class MyDBOpenHelper extends SQLiteOpenHelper {

    //    一共三个自定义
    public MyDBOpenHelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, "sjk", factory, 1);//数据库名字
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        // 创建dingdan表
        String sql = "CREATE TABLE IF NOT EXISTS dingdan(" +
                "id integer PRIMARY KEY AUTOINCREMENT," +
                "sje text not null," +
                "ssj text not null, " +
                "slb text not null," +
                "sfkf text not null," +
//                "sbz text);";
                "sbz text," +
                "num text);";//数据库新增一个门票数据的数据
//                "id integer PRIMARY KEY AUTOINCREMENT," +
//                "姓名 text not null," +
//                "时间 text not null, " +
//                "证件类型 text not null," +
//                "证件号 text not null," +
//                "编号 text);";
        sqLiteDatabase.execSQL(sql);

        //插入默认数据
        //插入默认数据
        sql = "INSERT INTO dingdan(sje,ssj,slb,sfkf,sbz,num)  VALUES('熊思帆','2022/11/23','身份证','210229','001','2')";//数据库dingdan表中插入一个新增的数据22  num ,'2'
        sqLiteDatabase.execSQL(sql);
        sql = "INSERT INTO dingdan(sje,ssj,slb,sfkf,sbz,num) VALUES('王鹤棣','2022/11/23','身份证','020121','002','2')";
        sqLiteDatabase.execSQL(sql);
        sql = "INSERT INTO dingdan(sje,ssj,slb,sfkf,sbz,num) VALUES('程嘉树','2022/12/09','学生证','161008','003','2')";
        sqLiteDatabase.execSQL(sql);
    }

    //    数据库升级
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
//        Log.d("---wwkk--","旧版本号：" + oldVersion + "新版本号：" + newVersion);
        // 旧版本大于新版本，则不执行
        if (oldVersion > newVersion){
            return;
        }
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS dingdan");
        // 重新创建
        onCreate(sqLiteDatabase);
    }

}
